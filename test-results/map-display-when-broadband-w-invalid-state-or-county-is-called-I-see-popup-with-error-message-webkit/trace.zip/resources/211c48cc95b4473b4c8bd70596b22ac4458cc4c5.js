import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/components/REPLInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b2f08eeb"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPLInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/frontend/styles/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=b2f08eeb"; const useState = __vite__cjsImport4_react["useState"];
import { ControlledInput } from "/src/frontend/components/ControlledInput.tsx";
import __vite__cjsImport6_react from "/node_modules/.vite/deps/react.js?v=b2f08eeb"; const useEffect = __vite__cjsImport6_react["useEffect"];
import { handleMockLoad, handleMockView, handleMockSearch, handleMockBroadband } from "/src/frontend/components/MockedREPLFunctions.tsx";
const commandRegistry = /* @__PURE__ */ new Map();
function registerCommand(command, func) {
  commandRegistry.set(command, func);
}
export function REPLInput(props) {
  _s();
  const [commandString, setCommandString] = useState("");
  const [count, setCount] = useState(0);
  const {
    mode,
    setMode,
    history,
    setHistory,
    commandResultMap,
    updateCommandResult,
    ariaLabel
  } = props;
  const handleRegister = async (args) => {
    if (args.length !== 2) {
      return "Invalid usage of 'register' command. Usage: register <commandName> <functionToExecute>";
    }
    const commandName = args[0];
    const toExecute = args[1];
    if (commandRegistry.has(commandName)) {
      return "Command: " + commandName + " is already registered";
    } else {
      registerCommand(commandName, eval(toExecute));
      return "Command registered: " + commandName;
    }
  };
  const handleMode = async (args2) => {
    const validModes = ["brief", "verbose"];
    if (args2.length !== 1) {
      return "Invalid usage of 'mode' command. Usage: mode <newMode>";
    }
    if (validModes.includes(args2[0])) {
      setMode(args2[0]);
      return "Mode changed to " + args2[0];
    } else {
      return "Invalid mode: " + args2[0] + ". Use brief or verbose";
    }
  };
  const handleLoad = async (args2) => {
    if (args2.length !== 1) {
      return "Invalid usage of 'load' command. Usage: load <URL>";
    }
    const filepath = args2[0].trim();
    try {
      const response = await fetch(`http://localhost:3232/loadcsv?filepath=${filepath}`);
      if (response.ok) {
        const data = await response.json();
        const resultMessage = data.result === "success" ? "File " + filepath + " loaded successfully" : data.error_message;
        return resultMessage;
      } else
        return "Failed to fetch data from the backend";
    } catch (error) {
      return "An error ocurred while loading the file: " + error;
    }
  };
  const handleView = async (args2) => {
    if (args2.length !== 0) {
      return "Invalid usage of 'view' command. Usage: view";
    }
    try {
      const response = await fetch("http://localhost:3232/viewcsv");
      if (response.ok) {
        const data = await response.json();
        const resultMessage = data.result === "success" ? data.data : data.error_message;
        return resultMessage;
      } else
        return "Failed to fetch data from the backend";
    } catch (error) {
      return "An error occurred while viewing the file: " + error;
    }
  };
  const handleSearch = async (args2) => {
    if (args2.length !== 3) {
      return "Invalid search command. Usage: search <hasHeaders> <value> <columnId>";
    }
    const hasHeaders = args2[0];
    const value = args2[1].includes("%") ? args2[1].replace("%", "%25").replace(/_/g, " ") : args2[1].replace(/_/g, " ");
    const columnId = args2[2].replace(/_/g, " ");
    try {
      const response = await fetch(`http://localhost:3232/searchcsv?headers=${hasHeaders}&value=${value}&colid=${columnId}`);
      if (response.ok) {
        const data = await response.json();
        const resultMessage = data.result === "success" ? data.data : data.error_message;
        return resultMessage;
      } else
        return "Failed to fetch data from the backend";
    } catch (error) {
      return "An error occurred while searching through the file: " + error;
    }
  };
  const handleBroadband = async (args2) => {
    if (args2.length !== 2) {
      return "Invalid broadband retrieval command. Usage: broadband <state> <county>";
    }
    const state = args2[0].replace(/_/g, " ");
    const county = args2[1].replace(/_/g, " ");
    try {
      const response = await fetch(`http://localhost:3232/broadband?state=${state}&county=${county}`);
      if (response.ok) {
        const data = await response.json();
        const resultMessage = data.result === "success" ? `time of retrieval: ${data.date_time} broadband access percent: ${data.broadband_access_percent}` : data.error_message;
        return resultMessage;
      } else
        return "Failed to fetch data from the backend";
    } catch (error) {
      return "An error occurred while fetching broadband data: " + error;
    }
  };
  useEffect(() => {
    registerCommand("register", handleRegister);
    registerCommand("mode", handleMode);
    registerCommand("load", handleLoad);
    registerCommand("view", handleView);
    registerCommand("search", handleSearch);
    registerCommand("broadband", handleBroadband);
    registerCommand("mockload", handleMockLoad);
    registerCommand("mockview", handleMockView);
    registerCommand("mocksearch", handleMockSearch);
    registerCommand("mockbroadband", handleMockBroadband);
  }, []);
  async function executeCommand(commandName2, args2) {
    const func = commandRegistry.get(commandName2);
    if (func) {
      try {
        const result = await func(args2);
        return result;
      } catch (error) {
        return `Error executing command. ${error}`;
      }
    } else {
      return `Command not found: ${commandName2}. Input "register <commandName> <function>" to register new command`;
    }
  }
  function handleSubmit(commandString2) {
    const trimmedCommand = commandString2.trim();
    if (trimmedCommand === "") {
      alert("Command cannot be empty");
      return;
    }
    const args2 = trimmedCommand.split(/\s+/);
    executeCommand(args2[0], args2.slice(1)).then((result) => {
      updateCommandResult(commandString2, result);
      setCount(count + 1);
    });
    setCommandString("");
  }
  function handleEnterPress(e) {
    if (e.key === "Enter") {
      handleSubmit(commandString);
    }
  }
  useEffect(() => {
    const handleKeyPress = (e) => {
      if (e.key === "b" && e.ctrlKey) {
        const inputElement = document.querySelector(".repl-command-box");
        if (inputElement && inputElement instanceof HTMLInputElement)
          inputElement.focus();
      }
    };
    document.addEventListener("keydown", handleKeyPress);
    return () => {
      document.removeEventListener("keydown", handleKeyPress);
    };
  }, []);
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-input", "aria-live": "polite", "aria-label": ariaLabel, children: [
    /* @__PURE__ */ jsxDEV("fieldset", { children: [
      /* @__PURE__ */ jsxDEV("legend", { children: "Enter a command:" }, void 0, false, {
        fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPLInput.tsx",
        lineNumber: 267,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, ariaLabel: "Command Input Box to type in commands", onKeyDown: handleEnterPress }, void 0, false, {
        fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPLInput.tsx",
        lineNumber: 268,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPLInput.tsx",
      lineNumber: 266,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: () => handleSubmit(commandString), children: "Submit" }, void 0, false, {
      fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPLInput.tsx",
      lineNumber: 270,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPLInput.tsx",
    lineNumber: 265,
    columnNumber: 10
  }, this);
}
_s(REPLInput, "ENpYGy7RzhD7Zwuou93UyOmtyqg=");
_c = REPLInput;
var _c;
$RefreshReg$(_c, "REPLInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPLInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOFNROzs7Ozs7Ozs7Ozs7Ozs7OztBQTlTUixPQUFPO0FBQ1AsU0FBbUNBLGdCQUFnQjtBQUNuRCxTQUFTQyx1QkFBdUI7QUFHaEMsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQ0VDLGdCQUNBQyxnQkFDQUMsa0JBQ0FDLDJCQUNLO0FBSVAsTUFBTUMsa0JBQWtCLG9CQUFJQyxJQUEwQjtBQU90RCxTQUFTQyxnQkFBZ0JDLFNBQWlCQyxNQUFvQjtBQUM1REosa0JBQWdCSyxJQUFJRixTQUFTQyxJQUFJO0FBQ25DO0FBbUJPLGdCQUFTRSxVQUFVQyxPQUF1QjtBQUFBQyxLQUFBO0FBQy9DLFFBQU0sQ0FBQ0MsZUFBZUMsZ0JBQWdCLElBQUlqQixTQUFpQixFQUFFO0FBQzdELFFBQU0sQ0FBQ2tCLE9BQU9DLFFBQVEsSUFBSW5CLFNBQWlCLENBQUM7QUFDNUMsUUFBTTtBQUFBLElBQ0pvQjtBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxFQUNGLElBQUlaO0FBTUosUUFBTWEsaUJBQStCLE9BQ25DQyxTQUNvQjtBQUNwQixRQUFJQSxLQUFLQyxXQUFXLEdBQUc7QUFDckIsYUFBTztBQUFBLElBQ1Q7QUFDQSxVQUFNQyxjQUFjRixLQUFLLENBQUM7QUFDMUIsVUFBTUcsWUFBWUgsS0FBSyxDQUFDO0FBQ3hCLFFBQUlyQixnQkFBZ0J5QixJQUFJRixXQUFXLEdBQUc7QUFDcEMsYUFBTyxjQUFjQSxjQUFjO0FBQUEsSUFDckMsT0FBTztBQUNMckIsc0JBQWdCcUIsYUFBYUcsS0FBS0YsU0FBUyxDQUFDO0FBQzVDLGFBQU8seUJBQXlCRDtBQUFBQSxJQUNsQztBQUFBLEVBQ0Y7QUFPQSxRQUFNSSxhQUEyQixPQUFPTixVQUFvQztBQUMxRSxVQUFNTyxhQUFhLENBQUMsU0FBUyxTQUFTO0FBQ3RDLFFBQUlQLE1BQUtDLFdBQVcsR0FBRztBQUNyQixhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUlNLFdBQVdDLFNBQVNSLE1BQUssQ0FBQyxDQUFDLEdBQUc7QUFDaENQLGNBQVFPLE1BQUssQ0FBQyxDQUFDO0FBQ2YsYUFBTyxxQkFBcUJBLE1BQUssQ0FBQztBQUFBLElBQ3BDLE9BQU87QUFDTCxhQUFPLG1CQUFtQkEsTUFBSyxDQUFDLElBQUk7QUFBQSxJQUN0QztBQUFBLEVBQ0Y7QUFNQSxRQUFNUyxhQUEyQixPQUFPVCxVQUFvQztBQUMxRSxRQUFJQSxNQUFLQyxXQUFXLEdBQUc7QUFDckIsYUFBTztBQUFBLElBQ1Q7QUFDQSxVQUFNUyxXQUFXVixNQUFLLENBQUMsRUFBRVcsS0FBSztBQUM5QixRQUFJO0FBQ0YsWUFBTUMsV0FBVyxNQUFNQyxNQUNwQiwwQ0FBeUNILFFBQVMsRUFDckQ7QUFDQSxVQUFJRSxTQUFTRSxJQUFJO0FBQ2YsY0FBTUMsT0FBTyxNQUFNSCxTQUFTSSxLQUFLO0FBQ2pDLGNBQU1DLGdCQUNKRixLQUFLRyxXQUFXLFlBQ1osVUFBVVIsV0FBVyx5QkFDckJLLEtBQUtJO0FBQ1gsZUFBT0Y7QUFBQUEsTUFDVDtBQUFPLGVBQU87QUFBQSxJQUNoQixTQUFTRyxPQUFPO0FBR2QsYUFBTyw4Q0FBOENBO0FBQUFBLElBQ3ZEO0FBQUEsRUFDRjtBQU1BLFFBQU1DLGFBQTJCLE9BQU9yQixVQUFvQztBQUMxRSxRQUFJQSxNQUFLQyxXQUFXLEdBQUc7QUFDckIsYUFBTztBQUFBLElBQ1Q7QUFDQSxRQUFJO0FBQ0YsWUFBTVcsV0FBVyxNQUFNQyxNQUFNLCtCQUErQjtBQUM1RCxVQUFJRCxTQUFTRSxJQUFJO0FBQ2YsY0FBTUMsT0FBTyxNQUFNSCxTQUFTSSxLQUFLO0FBQ2pDLGNBQU1DLGdCQUNKRixLQUFLRyxXQUFXLFlBQVlILEtBQUtBLE9BQU9BLEtBQUtJO0FBQy9DLGVBQU9GO0FBQUFBLE1BQ1Q7QUFBTyxlQUFPO0FBQUEsSUFDaEIsU0FBU0csT0FBTztBQUNkLGFBQU8sK0NBQStDQTtBQUFBQSxJQUN4RDtBQUFBLEVBQ0Y7QUFNQSxRQUFNRSxlQUE2QixPQUNqQ3RCLFVBQ29CO0FBQ3BCLFFBQUlBLE1BQUtDLFdBQVcsR0FBRztBQUNyQixhQUFPO0FBQUEsSUFDVDtBQUNBLFVBQU1zQixhQUFhdkIsTUFBSyxDQUFDO0FBQ3pCLFVBQU13QixRQUFReEIsTUFBSyxDQUFDLEVBQUVRLFNBQVMsR0FBRyxJQUM5QlIsTUFBSyxDQUFDLEVBQUV5QixRQUFRLEtBQUssS0FBSyxFQUFFQSxRQUFRLE1BQU0sR0FBRyxJQUM3Q3pCLE1BQUssQ0FBQyxFQUFFeUIsUUFBUSxNQUFNLEdBQUc7QUFDN0IsVUFBTUMsV0FBVzFCLE1BQUssQ0FBQyxFQUFFeUIsUUFBUSxNQUFNLEdBQUc7QUFFMUMsUUFBSTtBQUNGLFlBQU1iLFdBQVcsTUFBTUMsTUFDcEIsMkNBQTBDVSxVQUFXLFVBQVNDLEtBQU0sVUFBU0UsUUFBUyxFQUN6RjtBQUNBLFVBQUlkLFNBQVNFLElBQUk7QUFDZixjQUFNQyxPQUFPLE1BQU1ILFNBQVNJLEtBQUs7QUFDakMsY0FBTUMsZ0JBQ0pGLEtBQUtHLFdBQVcsWUFBWUgsS0FBS0EsT0FBT0EsS0FBS0k7QUFDL0MsZUFBT0Y7QUFBQUEsTUFDVDtBQUFPLGVBQU87QUFBQSxJQUNoQixTQUFTRyxPQUFPO0FBQ2QsYUFBTyx5REFBeURBO0FBQUFBLElBQ2xFO0FBQUEsRUFDRjtBQU1BLFFBQU1PLGtCQUFnQyxPQUNwQzNCLFVBQ29CO0FBQ3BCLFFBQUlBLE1BQUtDLFdBQVcsR0FBRztBQUNyQixhQUFPO0FBQUEsSUFDVDtBQUNBLFVBQU0yQixRQUFRNUIsTUFBSyxDQUFDLEVBQUV5QixRQUFRLE1BQU0sR0FBRztBQUN2QyxVQUFNSSxTQUFTN0IsTUFBSyxDQUFDLEVBQUV5QixRQUFRLE1BQU0sR0FBRztBQUV4QyxRQUFJO0FBQ0YsWUFBTWIsV0FBVyxNQUFNQyxNQUNwQix5Q0FBd0NlLEtBQU0sV0FBVUMsTUFBTyxFQUNsRTtBQUNBLFVBQUlqQixTQUFTRSxJQUFJO0FBQ2YsY0FBTUMsT0FBTyxNQUFNSCxTQUFTSSxLQUFLO0FBQ2pDLGNBQU1DLGdCQUNKRixLQUFLRyxXQUFXLFlBQ1gsc0JBQXFCSCxLQUFLZSxTQUFVLDhCQUE2QmYsS0FBS2dCLHdCQUF5QixLQUNoR2hCLEtBQUtJO0FBQ1gsZUFBT0Y7QUFBQUEsTUFDVDtBQUFPLGVBQU87QUFBQSxJQUNoQixTQUFTRyxPQUFPO0FBQ2QsYUFBTyxzREFBc0RBO0FBQUFBLElBQy9EO0FBQUEsRUFDRjtBQUtBOUMsWUFBVSxNQUFNO0FBQ2RPLG9CQUFnQixZQUFZa0IsY0FBYztBQUMxQ2xCLG9CQUFnQixRQUFReUIsVUFBVTtBQUNsQ3pCLG9CQUFnQixRQUFRNEIsVUFBVTtBQUNsQzVCLG9CQUFnQixRQUFRd0MsVUFBVTtBQUNsQ3hDLG9CQUFnQixVQUFVeUMsWUFBWTtBQUN0Q3pDLG9CQUFnQixhQUFhOEMsZUFBZTtBQUM1QzlDLG9CQUFnQixZQUFZTixjQUFjO0FBQzFDTSxvQkFBZ0IsWUFBWUwsY0FBYztBQUMxQ0ssb0JBQWdCLGNBQWNKLGdCQUFnQjtBQUM5Q0ksb0JBQWdCLGlCQUFpQkgsbUJBQW1CO0FBQUEsRUFDdEQsR0FBRyxFQUFFO0FBT0wsaUJBQWVzRCxlQUNiOUIsY0FDQUYsT0FDaUI7QUFDakIsVUFBTWpCLE9BQU9KLGdCQUFnQnNELElBQUkvQixZQUFXO0FBRTVDLFFBQUluQixNQUFNO0FBQ1IsVUFBSTtBQUVGLGNBQU1tQyxTQUFTLE1BQU1uQyxLQUFLaUIsS0FBSTtBQUM5QixlQUFPa0I7QUFBQUEsTUFDVCxTQUFTRSxPQUFPO0FBQ2QsZUFBUSw0QkFBMkJBLEtBQU07QUFBQSxNQUMzQztBQUFBLElBQ0YsT0FBTztBQUNMLGFBQVEsc0JBQXFCbEIsWUFBWTtBQUFBLElBQzNDO0FBQUEsRUFDRjtBQU1BLFdBQVNnQyxhQUFhOUMsZ0JBQXVCO0FBQzNDLFVBQU0rQyxpQkFBaUIvQyxlQUFjdUIsS0FBSztBQUMxQyxRQUFJd0IsbUJBQW1CLElBQUk7QUFDekJDLFlBQU0seUJBQXlCO0FBQy9CO0FBQUEsSUFDRjtBQUdBLFVBQU1wQyxRQUFPbUMsZUFBZUUsTUFBTSxLQUFLO0FBRXZDTCxtQkFBZWhDLE1BQUssQ0FBQyxHQUFHQSxNQUFLc0MsTUFBTSxDQUFDLENBQUMsRUFBRUMsS0FBTXJCLFlBQVc7QUFDdERyQiwwQkFBb0JULGdCQUFlOEIsTUFBTTtBQUN6QzNCLGVBQVNELFFBQVEsQ0FBQztBQUFBLElBQ3BCLENBQUM7QUFFREQscUJBQWlCLEVBQUU7QUFBQSxFQUNyQjtBQVFBLFdBQVNtRCxpQkFBaUJDLEdBQXdCO0FBQ2hELFFBQUlBLEVBQUVDLFFBQVEsU0FBUztBQUNyQlIsbUJBQWE5QyxhQUFhO0FBQUEsSUFDNUI7QUFBQSxFQUNGO0FBS0FkLFlBQVUsTUFBTTtBQUNkLFVBQU1xRSxpQkFBaUJBLENBQUNGLE1BQXFCO0FBQzNDLFVBQUlBLEVBQUVDLFFBQVEsT0FBT0QsRUFBRUcsU0FBUztBQUM5QixjQUFNQyxlQUFlQyxTQUFTQyxjQUFjLG1CQUFtQjtBQUMvRCxZQUFJRixnQkFBZ0JBLHdCQUF3Qkc7QUFDMUNILHVCQUFhSSxNQUFNO0FBQUEsTUFDdkI7QUFBQSxJQUNGO0FBRUFILGFBQVNJLGlCQUFpQixXQUFXUCxjQUFjO0FBRW5ELFdBQU8sTUFBTTtBQUNYRyxlQUFTSyxvQkFBb0IsV0FBV1IsY0FBYztBQUFBLElBQ3hEO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFJTCxTQUNFLHVCQUFDLFNBQUksV0FBVSxjQUFhLGFBQVUsVUFBUyxjQUFZN0MsV0FDekQ7QUFBQSwyQkFBQyxjQUNDO0FBQUEsNkJBQUMsWUFBTyxnQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdCO0FBQUEsTUFDeEIsdUJBQUMsbUJBQ0MsT0FBT1YsZUFDUCxVQUFVQyxrQkFDVixXQUFXLHlDQUNYLFdBQVdtRCxvQkFKYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSThCO0FBQUEsU0FOaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFDQSx1QkFBQyxZQUFPLFNBQVMsTUFBTU4sYUFBYTlDLGFBQWEsR0FBRyxzQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRDtBQUFBLE9BVjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FXQTtBQUVKO0FBQUNELEdBOVFlRixXQUFTO0FBQUFtRSxLQUFUbkU7QUFBUyxJQUFBbUU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQ29udHJvbGxlZElucHV0IiwidXNlRWZmZWN0IiwiaGFuZGxlTW9ja0xvYWQiLCJoYW5kbGVNb2NrVmlldyIsImhhbmRsZU1vY2tTZWFyY2giLCJoYW5kbGVNb2NrQnJvYWRiYW5kIiwiY29tbWFuZFJlZ2lzdHJ5IiwiTWFwIiwicmVnaXN0ZXJDb21tYW5kIiwiY29tbWFuZCIsImZ1bmMiLCJzZXQiLCJSRVBMSW5wdXQiLCJwcm9wcyIsIl9zIiwiY29tbWFuZFN0cmluZyIsInNldENvbW1hbmRTdHJpbmciLCJjb3VudCIsInNldENvdW50IiwibW9kZSIsInNldE1vZGUiLCJoaXN0b3J5Iiwic2V0SGlzdG9yeSIsImNvbW1hbmRSZXN1bHRNYXAiLCJ1cGRhdGVDb21tYW5kUmVzdWx0IiwiYXJpYUxhYmVsIiwiaGFuZGxlUmVnaXN0ZXIiLCJhcmdzIiwibGVuZ3RoIiwiY29tbWFuZE5hbWUiLCJ0b0V4ZWN1dGUiLCJoYXMiLCJldmFsIiwiaGFuZGxlTW9kZSIsInZhbGlkTW9kZXMiLCJpbmNsdWRlcyIsImhhbmRsZUxvYWQiLCJmaWxlcGF0aCIsInRyaW0iLCJyZXNwb25zZSIsImZldGNoIiwib2siLCJkYXRhIiwianNvbiIsInJlc3VsdE1lc3NhZ2UiLCJyZXN1bHQiLCJlcnJvcl9tZXNzYWdlIiwiZXJyb3IiLCJoYW5kbGVWaWV3IiwiaGFuZGxlU2VhcmNoIiwiaGFzSGVhZGVycyIsInZhbHVlIiwicmVwbGFjZSIsImNvbHVtbklkIiwiaGFuZGxlQnJvYWRiYW5kIiwic3RhdGUiLCJjb3VudHkiLCJkYXRlX3RpbWUiLCJicm9hZGJhbmRfYWNjZXNzX3BlcmNlbnQiLCJleGVjdXRlQ29tbWFuZCIsImdldCIsImhhbmRsZVN1Ym1pdCIsInRyaW1tZWRDb21tYW5kIiwiYWxlcnQiLCJzcGxpdCIsInNsaWNlIiwidGhlbiIsImhhbmRsZUVudGVyUHJlc3MiLCJlIiwia2V5IiwiaGFuZGxlS2V5UHJlc3MiLCJjdHJsS2V5IiwiaW5wdXRFbGVtZW50IiwiZG9jdW1lbnQiLCJxdWVyeVNlbGVjdG9yIiwiSFRNTElucHV0RWxlbWVudCIsImZvY3VzIiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJFUExJbnB1dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XG5pbXBvcnQgeyBEaXNwYXRjaCwgU2V0U3RhdGVBY3Rpb24sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBDb250cm9sbGVkSW5wdXQgfSBmcm9tIFwiLi9Db250cm9sbGVkSW5wdXRcIjtcbmltcG9ydCB7IEhpc3RvcnlJdGVtIH0gZnJvbSBcIi4uL3R5cGVzL0hpc3RvcnlJdGVtXCI7XG5pbXBvcnQgeyBSRVBMRnVuY3Rpb24gfSBmcm9tIFwiLi4vdHlwZXMvUkVQTEZ1bmN0aW9uXCI7XG5pbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7XG4gIGhhbmRsZU1vY2tMb2FkLFxuICBoYW5kbGVNb2NrVmlldyxcbiAgaGFuZGxlTW9ja1NlYXJjaCxcbiAgaGFuZGxlTW9ja0Jyb2FkYmFuZCxcbn0gZnJvbSBcIi4vTW9ja2VkUkVQTEZ1bmN0aW9uc1wiO1xuLyoqXG4gKiBNYXAgc3RvcmluZyByZWdpc3RlcmVkIGNvbW1hbmRzXG4gKi9cbmNvbnN0IGNvbW1hbmRSZWdpc3RyeSA9IG5ldyBNYXA8c3RyaW5nLCBSRVBMRnVuY3Rpb24+KCk7XG5cbi8qKlxuICogSGVscGVyIGZ1bmN0aW9uIHJlc3BvbnNpYmxlIGZvciByZWdpc3RlcmluZyBjb21tYW5kc1xuICogQHBhcmFtIHtzdHJpbmd9IGNvbW1hbmQgLSBUaGUgbmFtZSBvZiB0aGUgY29tbWFuZCB0byBiZSByZWdpc3RlcmVkXG4gKiBAcGFyYW0ge1JFUExGdW5jdGlvbn0gZnVuYyAtIFRoZSBmdW5jdGlvbiB0byBiZSBleGVjdXRlZCB1cG9uIGNvbW1hbmQgY2FsbFxuICovXG5mdW5jdGlvbiByZWdpc3RlckNvbW1hbmQoY29tbWFuZDogc3RyaW5nLCBmdW5jOiBSRVBMRnVuY3Rpb24pIHtcbiAgY29tbWFuZFJlZ2lzdHJ5LnNldChjb21tYW5kLCBmdW5jKTtcbn1cblxuLyoqXG4gKiBQcm9wcyBmb3IgdGhlIFJFUExJbnB1dFByb3BzIGNvbXBvbmVudFxuICovXG5pbnRlcmZhY2UgUkVQTElucHV0UHJvcHMge1xuICBoaXN0b3J5OiBIaXN0b3J5SXRlbVtdO1xuICBzZXRIaXN0b3J5OiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxIaXN0b3J5SXRlbVtdPj47XG4gIG1vZGU6IHN0cmluZztcbiAgc2V0TW9kZTogKG5ld01vZGU6IHN0cmluZykgPT4gdm9pZDtcbiAgY29tbWFuZFJlc3VsdE1hcDogTWFwPEhpc3RvcnlJdGVtLCBbW11dIHwgc3RyaW5nPjtcbiAgdXBkYXRlQ29tbWFuZFJlc3VsdDogKGNvbW1hbmQ6IHN0cmluZywgb3V0cHV0OiBbW11dIHwgc3RyaW5nKSA9PiB2b2lkO1xuICBhcmlhTGFiZWw6IHN0cmluZztcbn1cblxuLyoqXG4gKiBSZWFjdCBjb21wb25lbnQgcmVzcG9uc2libGUgZm9yIGhhbmRsaW5nIHVzZXIgaW5wdXQgYW5kIGV4ZWN1dGluZyBjb21tYW5kc1xuICogQHBhcmFtIHtSRVBMSW5wdXRQcm9wc30gcHJvcHMgLSBUaGUgcHJvcGVydGllcyByZXF1aXJlZCBmb3IgcmVuZGVyaW5nIHRoZSBjb21wb25lbnRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFJFUExJbnB1dChwcm9wczogUkVQTElucHV0UHJvcHMpIHtcbiAgY29uc3QgW2NvbW1hbmRTdHJpbmcsIHNldENvbW1hbmRTdHJpbmddID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcbiAgY29uc3QgW2NvdW50LCBzZXRDb3VudF0gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuICBjb25zdCB7XG4gICAgbW9kZSxcbiAgICBzZXRNb2RlLFxuICAgIGhpc3RvcnksXG4gICAgc2V0SGlzdG9yeSxcbiAgICBjb21tYW5kUmVzdWx0TWFwLFxuICAgIHVwZGF0ZUNvbW1hbmRSZXN1bHQsXG4gICAgYXJpYUxhYmVsLFxuICB9ID0gcHJvcHM7XG5cbiAgLyoqXG4gICAqIFJFUExGdW5jdGlvbiBoYW5kbGluZyB0aGUgcmVnaXN0cmF0aW9uIG9mIGEgdXNlci1zcGVjaWZpZWQgY29tbWFuZFxuICAgKiBAcGFyYW0ge3N0cmluZ1tdfSBhcmdzIC0gRGV0YWlscyBvZiBhIHRvLWJlLXJlZ2lzdGVyZWQgZnVuY3Rpb24gKGNvbW1hbmROYW1lLCBmdW5jdGlvbiBleGVjdXRlZCB1cG9uIGNvbW1hbmQpXG4gICAqL1xuICBjb25zdCBoYW5kbGVSZWdpc3RlcjogUkVQTEZ1bmN0aW9uID0gYXN5bmMgKFxuICAgIGFyZ3M6IHN0cmluZ1tdXG4gICk6IFByb21pc2U8c3RyaW5nPiA9PiB7XG4gICAgaWYgKGFyZ3MubGVuZ3RoICE9PSAyKSB7XG4gICAgICByZXR1cm4gXCJJbnZhbGlkIHVzYWdlIG9mICdyZWdpc3RlcicgY29tbWFuZC4gVXNhZ2U6IHJlZ2lzdGVyIDxjb21tYW5kTmFtZT4gPGZ1bmN0aW9uVG9FeGVjdXRlPlwiO1xuICAgIH1cbiAgICBjb25zdCBjb21tYW5kTmFtZSA9IGFyZ3NbMF07XG4gICAgY29uc3QgdG9FeGVjdXRlID0gYXJnc1sxXTtcbiAgICBpZiAoY29tbWFuZFJlZ2lzdHJ5Lmhhcyhjb21tYW5kTmFtZSkpIHtcbiAgICAgIHJldHVybiBcIkNvbW1hbmQ6IFwiICsgY29tbWFuZE5hbWUgKyBcIiBpcyBhbHJlYWR5IHJlZ2lzdGVyZWRcIjtcbiAgICB9IGVsc2Uge1xuICAgICAgcmVnaXN0ZXJDb21tYW5kKGNvbW1hbmROYW1lLCBldmFsKHRvRXhlY3V0ZSkpO1xuICAgICAgcmV0dXJuIFwiQ29tbWFuZCByZWdpc3RlcmVkOiBcIiArIGNvbW1hbmROYW1lO1xuICAgIH1cbiAgfTtcblxuICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLyoqXG4gICAqIEZ1bmN0aW9uIGhhbmRsaW5nIG1vZGUgY2hhbmdlcyBvZiB0aGUgUkVQTCBpbnRlcmZhY2VcbiAgICogQHBhcmFtIHtzdHJpbmdbXX0gYXJncyAtIFRoZSBuZXcgbW9kZSB0byBzZXRcbiAgICovXG4gIGNvbnN0IGhhbmRsZU1vZGU6IFJFUExGdW5jdGlvbiA9IGFzeW5jIChhcmdzOiBzdHJpbmdbXSk6IFByb21pc2U8c3RyaW5nPiA9PiB7XG4gICAgY29uc3QgdmFsaWRNb2RlcyA9IFtcImJyaWVmXCIsIFwidmVyYm9zZVwiXTtcbiAgICBpZiAoYXJncy5sZW5ndGggIT09IDEpIHtcbiAgICAgIHJldHVybiBcIkludmFsaWQgdXNhZ2Ugb2YgJ21vZGUnIGNvbW1hbmQuIFVzYWdlOiBtb2RlIDxuZXdNb2RlPlwiO1xuICAgIH1cbiAgICBpZiAodmFsaWRNb2Rlcy5pbmNsdWRlcyhhcmdzWzBdKSkge1xuICAgICAgc2V0TW9kZShhcmdzWzBdKTtcbiAgICAgIHJldHVybiBcIk1vZGUgY2hhbmdlZCB0byBcIiArIGFyZ3NbMF07XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBcIkludmFsaWQgbW9kZTogXCIgKyBhcmdzWzBdICsgXCIuIFVzZSBicmllZiBvciB2ZXJib3NlXCI7XG4gICAgfVxuICB9O1xuXG4gIC8qKlxuICAgKiBGdW5jdGlvbiBoYW5kbGluZyBsb2FkaW5nIHRoZSBmaWxlXG4gICAqIEBwYXJhbSB7c3RyaW5nW119IGFyZ3MgLSBUaGUgZmlsZSBwYXRoIG9mIGEgZmlsZSB0byBiZSBsb2FkZWQgKG11c3QgYmUgd2l0aGluIHRoZSBkYXRhIGRpcmVjdG9yeSlcbiAgICovXG4gIGNvbnN0IGhhbmRsZUxvYWQ6IFJFUExGdW5jdGlvbiA9IGFzeW5jIChhcmdzOiBzdHJpbmdbXSk6IFByb21pc2U8c3RyaW5nPiA9PiB7XG4gICAgaWYgKGFyZ3MubGVuZ3RoICE9PSAxKSB7XG4gICAgICByZXR1cm4gXCJJbnZhbGlkIHVzYWdlIG9mICdsb2FkJyBjb21tYW5kLiBVc2FnZTogbG9hZCA8VVJMPlwiO1xuICAgIH1cbiAgICBjb25zdCBmaWxlcGF0aCA9IGFyZ3NbMF0udHJpbSgpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKFxuICAgICAgICBgaHR0cDovL2xvY2FsaG9zdDozMjMyL2xvYWRjc3Y/ZmlsZXBhdGg9JHtmaWxlcGF0aH1gXG4gICAgICApO1xuICAgICAgaWYgKHJlc3BvbnNlLm9rKSB7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIGNvbnN0IHJlc3VsdE1lc3NhZ2UgPVxuICAgICAgICAgIGRhdGEucmVzdWx0ID09PSBcInN1Y2Nlc3NcIlxuICAgICAgICAgICAgPyBcIkZpbGUgXCIgKyBmaWxlcGF0aCArIFwiIGxvYWRlZCBzdWNjZXNzZnVsbHlcIlxuICAgICAgICAgICAgOiBkYXRhLmVycm9yX21lc3NhZ2U7XG4gICAgICAgIHJldHVybiByZXN1bHRNZXNzYWdlO1xuICAgICAgfSBlbHNlIHJldHVybiBcIkZhaWxlZCB0byBmZXRjaCBkYXRhIGZyb20gdGhlIGJhY2tlbmRcIjtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgLy8gSW1wbGVtZW50IHRoZSBsb2dpYyB0byBsb2FkIHRoZSBmaWxlIGJhc2VkIG9uIHRoZSBwcm92aWRlZCAndXJsJy5cbiAgICAgIC8vIFJldHVybiBhbiBhcHByb3ByaWF0ZSByZXN1bHQgbWVzc2FnZS5cbiAgICAgIHJldHVybiBcIkFuIGVycm9yIG9jdXJyZWQgd2hpbGUgbG9hZGluZyB0aGUgZmlsZTogXCIgKyBlcnJvcjtcbiAgICB9XG4gIH07XG5cbiAgLyoqXG4gICAqIEZ1bmN0aW9uIGhhbmRsaW5nIHZpZXdpbmcgdGhlIGxvYWRlZCBkYXRhc2V0XG4gICAqIEBwYXJhbSB7c3RyaW5nW119IGFyZ3MgLSBOb25lIChlbXB0eSlcbiAgICovXG4gIGNvbnN0IGhhbmRsZVZpZXc6IFJFUExGdW5jdGlvbiA9IGFzeW5jIChhcmdzOiBzdHJpbmdbXSk6IFByb21pc2U8c3RyaW5nPiA9PiB7XG4gICAgaWYgKGFyZ3MubGVuZ3RoICE9PSAwKSB7XG4gICAgICByZXR1cm4gXCJJbnZhbGlkIHVzYWdlIG9mICd2aWV3JyBjb21tYW5kLiBVc2FnZTogdmlld1wiO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcImh0dHA6Ly9sb2NhbGhvc3Q6MzIzMi92aWV3Y3N2XCIpO1xuICAgICAgaWYgKHJlc3BvbnNlLm9rKSB7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIGNvbnN0IHJlc3VsdE1lc3NhZ2UgPVxuICAgICAgICAgIGRhdGEucmVzdWx0ID09PSBcInN1Y2Nlc3NcIiA/IGRhdGEuZGF0YSA6IGRhdGEuZXJyb3JfbWVzc2FnZTtcbiAgICAgICAgcmV0dXJuIHJlc3VsdE1lc3NhZ2U7XG4gICAgICB9IGVsc2UgcmV0dXJuIFwiRmFpbGVkIHRvIGZldGNoIGRhdGEgZnJvbSB0aGUgYmFja2VuZFwiO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICByZXR1cm4gXCJBbiBlcnJvciBvY2N1cnJlZCB3aGlsZSB2aWV3aW5nIHRoZSBmaWxlOiBcIiArIGVycm9yO1xuICAgIH1cbiAgfTtcblxuICAvKipcbiAgICogRnVuY3Rpb24gaGFuZGxpbmcgc2VhcmNoaW5nIHdpdGhpbiB0aGUgbG9hZGVkIGRhdGFzZXRcbiAgICogQHBhcmFtIHtzdHJpbmdbXX0gYXJncyAtIFRoZSBzZWFyY2ggcXVlcnkgcGFyYW1ldGVyc1xuICAgKi9cbiAgY29uc3QgaGFuZGxlU2VhcmNoOiBSRVBMRnVuY3Rpb24gPSBhc3luYyAoXG4gICAgYXJnczogc3RyaW5nW11cbiAgKTogUHJvbWlzZTxzdHJpbmc+ID0+IHtcbiAgICBpZiAoYXJncy5sZW5ndGggIT09IDMpIHtcbiAgICAgIHJldHVybiBcIkludmFsaWQgc2VhcmNoIGNvbW1hbmQuIFVzYWdlOiBzZWFyY2ggPGhhc0hlYWRlcnM+IDx2YWx1ZT4gPGNvbHVtbklkPlwiO1xuICAgIH1cbiAgICBjb25zdCBoYXNIZWFkZXJzID0gYXJnc1swXTtcbiAgICBjb25zdCB2YWx1ZSA9IGFyZ3NbMV0uaW5jbHVkZXMoXCIlXCIpXG4gICAgICA/IGFyZ3NbMV0ucmVwbGFjZShcIiVcIiwgXCIlMjVcIikucmVwbGFjZSgvXy9nLCBcIiBcIilcbiAgICAgIDogYXJnc1sxXS5yZXBsYWNlKC9fL2csIFwiIFwiKTtcbiAgICBjb25zdCBjb2x1bW5JZCA9IGFyZ3NbMl0ucmVwbGFjZSgvXy9nLCBcIiBcIik7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcbiAgICAgICAgYGh0dHA6Ly9sb2NhbGhvc3Q6MzIzMi9zZWFyY2hjc3Y/aGVhZGVycz0ke2hhc0hlYWRlcnN9JnZhbHVlPSR7dmFsdWV9JmNvbGlkPSR7Y29sdW1uSWR9YFxuICAgICAgKTtcbiAgICAgIGlmIChyZXNwb25zZS5vaykge1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICBjb25zdCByZXN1bHRNZXNzYWdlID1cbiAgICAgICAgICBkYXRhLnJlc3VsdCA9PT0gXCJzdWNjZXNzXCIgPyBkYXRhLmRhdGEgOiBkYXRhLmVycm9yX21lc3NhZ2U7XG4gICAgICAgIHJldHVybiByZXN1bHRNZXNzYWdlO1xuICAgICAgfSBlbHNlIHJldHVybiBcIkZhaWxlZCB0byBmZXRjaCBkYXRhIGZyb20gdGhlIGJhY2tlbmRcIjtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgcmV0dXJuIFwiQW4gZXJyb3Igb2NjdXJyZWQgd2hpbGUgc2VhcmNoaW5nIHRocm91Z2ggdGhlIGZpbGU6IFwiICsgZXJyb3I7XG4gICAgfVxuICB9O1xuXG4gIC8qKlxuICAgKiBGdW5jdGlvbiBoYW5kbGluZyByZXRyaWV2aW5nIGJyb2FkYmFuZCBhY2Nlc3MgcGVyY2VudGFnZVxuICAgKiBAcGFyYW0ge3N0cmluZ1tdfSBhcmdzIC0gVGhlIGJyb2FkYmFuZCBxdWVyeSBwYXJhbWV0ZXJzXG4gICAqL1xuICBjb25zdCBoYW5kbGVCcm9hZGJhbmQ6IFJFUExGdW5jdGlvbiA9IGFzeW5jIChcbiAgICBhcmdzOiBzdHJpbmdbXVxuICApOiBQcm9taXNlPHN0cmluZz4gPT4ge1xuICAgIGlmIChhcmdzLmxlbmd0aCAhPT0gMikge1xuICAgICAgcmV0dXJuIFwiSW52YWxpZCBicm9hZGJhbmQgcmV0cmlldmFsIGNvbW1hbmQuIFVzYWdlOiBicm9hZGJhbmQgPHN0YXRlPiA8Y291bnR5PlwiO1xuICAgIH1cbiAgICBjb25zdCBzdGF0ZSA9IGFyZ3NbMF0ucmVwbGFjZSgvXy9nLCBcIiBcIik7XG4gICAgY29uc3QgY291bnR5ID0gYXJnc1sxXS5yZXBsYWNlKC9fL2csIFwiIFwiKTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKFxuICAgICAgICBgaHR0cDovL2xvY2FsaG9zdDozMjMyL2Jyb2FkYmFuZD9zdGF0ZT0ke3N0YXRlfSZjb3VudHk9JHtjb3VudHl9YFxuICAgICAgKTtcbiAgICAgIGlmIChyZXNwb25zZS5vaykge1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICBjb25zdCByZXN1bHRNZXNzYWdlID1cbiAgICAgICAgICBkYXRhLnJlc3VsdCA9PT0gXCJzdWNjZXNzXCJcbiAgICAgICAgICAgID8gYHRpbWUgb2YgcmV0cmlldmFsOiAke2RhdGEuZGF0ZV90aW1lfSBicm9hZGJhbmQgYWNjZXNzIHBlcmNlbnQ6ICR7ZGF0YS5icm9hZGJhbmRfYWNjZXNzX3BlcmNlbnR9YFxuICAgICAgICAgICAgOiBkYXRhLmVycm9yX21lc3NhZ2U7XG4gICAgICAgIHJldHVybiByZXN1bHRNZXNzYWdlO1xuICAgICAgfSBlbHNlIHJldHVybiBcIkZhaWxlZCB0byBmZXRjaCBkYXRhIGZyb20gdGhlIGJhY2tlbmRcIjtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgcmV0dXJuIFwiQW4gZXJyb3Igb2NjdXJyZWQgd2hpbGUgZmV0Y2hpbmcgYnJvYWRiYW5kIGRhdGE6IFwiICsgZXJyb3I7XG4gICAgfVxuICB9O1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLyoqXG4gICAqIEZ1bmN0aW9ucyByZWdpc3RlcmVkIHVwb24gY29tcG9uZW50IG1vdW50XG4gICAqL1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHJlZ2lzdGVyQ29tbWFuZChcInJlZ2lzdGVyXCIsIGhhbmRsZVJlZ2lzdGVyKTtcbiAgICByZWdpc3RlckNvbW1hbmQoXCJtb2RlXCIsIGhhbmRsZU1vZGUpO1xuICAgIHJlZ2lzdGVyQ29tbWFuZChcImxvYWRcIiwgaGFuZGxlTG9hZCk7XG4gICAgcmVnaXN0ZXJDb21tYW5kKFwidmlld1wiLCBoYW5kbGVWaWV3KTtcbiAgICByZWdpc3RlckNvbW1hbmQoXCJzZWFyY2hcIiwgaGFuZGxlU2VhcmNoKTtcbiAgICByZWdpc3RlckNvbW1hbmQoXCJicm9hZGJhbmRcIiwgaGFuZGxlQnJvYWRiYW5kKTtcbiAgICByZWdpc3RlckNvbW1hbmQoXCJtb2NrbG9hZFwiLCBoYW5kbGVNb2NrTG9hZCk7XG4gICAgcmVnaXN0ZXJDb21tYW5kKFwibW9ja3ZpZXdcIiwgaGFuZGxlTW9ja1ZpZXcpO1xuICAgIHJlZ2lzdGVyQ29tbWFuZChcIm1vY2tzZWFyY2hcIiwgaGFuZGxlTW9ja1NlYXJjaCk7XG4gICAgcmVnaXN0ZXJDb21tYW5kKFwibW9ja2Jyb2FkYmFuZFwiLCBoYW5kbGVNb2NrQnJvYWRiYW5kKTtcbiAgfSwgW10pO1xuXG4gIC8qKlxuICAgKiBIZWxwZXIgZnVuY3Rpb24gZm9yIGV4ZWN1dGluZyB0aGUgY29tbWFuZCB1cG9uIGlucHV0IHN1Ym1pc3Npb25cbiAgICogQHBhcmFtIHtzdHJpbmd9IGNvbW1hbmROYW1lIC0gTmFtZSBvZiB0aGUgY29tbWFuZFxuICAgKiBAcGFyYW0ge3N0cmluZ1tdfSBhcmdzIC0gQXJndW1lbnRzIGZvciB0aGUgdG8tYmUtZXhlY3V0ZWQgZnVuY3Rpb24gYXNzaWduZWQgdG8gdGhlIGNvbW1hbmRcbiAgICovXG4gIGFzeW5jIGZ1bmN0aW9uIGV4ZWN1dGVDb21tYW5kKFxuICAgIGNvbW1hbmROYW1lOiBzdHJpbmcsXG4gICAgYXJnczogc3RyaW5nW11cbiAgKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCBmdW5jID0gY29tbWFuZFJlZ2lzdHJ5LmdldChjb21tYW5kTmFtZSk7XG5cbiAgICBpZiAoZnVuYykge1xuICAgICAgdHJ5IHtcbiAgICAgICAgLy8gRXhlY3V0ZSB0aGUgcmVnaXN0ZXJlZCBmdW5jdGlvbiBhbmQgcGFzcyB0aGUgYXJndW1lbnRzLCBleGNsdWRpbmcgdGhlIGNvbW1hbmQgaXRzZWxmXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGZ1bmMoYXJncyk7XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICByZXR1cm4gYEVycm9yIGV4ZWN1dGluZyBjb21tYW5kLiAke2Vycm9yfWA7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBgQ29tbWFuZCBub3QgZm91bmQ6ICR7Y29tbWFuZE5hbWV9LiBJbnB1dCBcInJlZ2lzdGVyIDxjb21tYW5kTmFtZT4gPGZ1bmN0aW9uPlwiIHRvIHJlZ2lzdGVyIG5ldyBjb21tYW5kYDtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogRnVuY3Rpb24gdHJpZ2dlcmVkIHdoZW4gdGhlIFwiU3VibWl0XCIgYnV0dG9uIGlzIGNsaWNrZWQgdG8gcHJvY2VzcyB0aGUgdXNlcidzIGNvbW1hbmRcbiAgICogQHBhcmFtIHtzdHJpbmd9IGNvbW1hbmRTdHJpbmcgLSBUaGUgd2hvbGUgdXNlciBpbnB1dFxuICAgKi9cbiAgZnVuY3Rpb24gaGFuZGxlU3VibWl0KGNvbW1hbmRTdHJpbmc6IHN0cmluZykge1xuICAgIGNvbnN0IHRyaW1tZWRDb21tYW5kID0gY29tbWFuZFN0cmluZy50cmltKCk7XG4gICAgaWYgKHRyaW1tZWRDb21tYW5kID09PSBcIlwiKSB7XG4gICAgICBhbGVydChcIkNvbW1hbmQgY2Fubm90IGJlIGVtcHR5XCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIGFycmF5IG9mIGFsbCB3b3JkcyBlbnRlcmVkIGJ5IHVzZXIgaW4gdGhlIGNvbW1hbmQgaW5wdXRcbiAgICBjb25zdCBhcmdzID0gdHJpbW1lZENvbW1hbmQuc3BsaXQoL1xccysvKTtcbiAgICAvLyBhcmdzWzBdIGlzIHRoZSBjb21tYW5kIG5hbWUsIGFyZ3Muc2xpY2UoMSkgaXMgYW4gYXJyYXkgb2YgZXZlcnl0aGluZyBFWENFUFQgZm9yIHRoZSBjb21tYW5kIG5hbWVcbiAgICBleGVjdXRlQ29tbWFuZChhcmdzWzBdLCBhcmdzLnNsaWNlKDEpKS50aGVuKChyZXN1bHQpID0+IHtcbiAgICAgIHVwZGF0ZUNvbW1hbmRSZXN1bHQoY29tbWFuZFN0cmluZywgcmVzdWx0KTtcbiAgICAgIHNldENvdW50KGNvdW50ICsgMSk7XG4gICAgfSk7XG5cbiAgICBzZXRDb21tYW5kU3RyaW5nKFwiXCIpO1xuICB9XG5cbiAgLy9BbGwga2V5Ym9hcmQgc2hvcnRjdXRzIGhlcmVcbiAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLyoqXG4gICAqIEhhbmRsZXMga2V5Ym9hcmQgc2hvcnRjdXQgdG8gc3VibWl0IGJ5IHByZXNzaW5nIEVudGVyIGluIGNvbW1hbmQgYm94XG4gICAqIEBwYXJhbSBlIGtleWJvYXJkIGV2ZW50IG9mIHByZXNzaW5nIEVudGVyIGtleVxuICAgKi9cbiAgZnVuY3Rpb24gaGFuZGxlRW50ZXJQcmVzcyhlOiBSZWFjdC5LZXlib2FyZEV2ZW50KSB7XG4gICAgaWYgKGUua2V5ID09PSBcIkVudGVyXCIpIHtcbiAgICAgIGhhbmRsZVN1Ym1pdChjb21tYW5kU3RyaW5nKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogV2VicGFnZSBhbHdheXMgbGlzdGVucyBvdXQgZm9yIEN0cmwrYiB0byBuYXZpZ2F0ZSBjdXJzb3IgdG8gY29tbWFuZCBib3hcbiAgICovXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgaGFuZGxlS2V5UHJlc3MgPSAoZTogS2V5Ym9hcmRFdmVudCkgPT4ge1xuICAgICAgaWYgKGUua2V5ID09PSBcImJcIiAmJiBlLmN0cmxLZXkpIHtcbiAgICAgICAgY29uc3QgaW5wdXRFbGVtZW50ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5yZXBsLWNvbW1hbmQtYm94XCIpO1xuICAgICAgICBpZiAoaW5wdXRFbGVtZW50ICYmIGlucHV0RWxlbWVudCBpbnN0YW5jZW9mIEhUTUxJbnB1dEVsZW1lbnQpXG4gICAgICAgICAgaW5wdXRFbGVtZW50LmZvY3VzKCk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIGhhbmRsZUtleVByZXNzKTtcblxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCBoYW5kbGVLZXlQcmVzcyk7XG4gICAgfTtcbiAgfSwgW10pO1xuXG4gIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJlcGwtaW5wdXRcIiBhcmlhLWxpdmU9XCJwb2xpdGVcIiBhcmlhLWxhYmVsPXthcmlhTGFiZWx9PlxuICAgICAgPGZpZWxkc2V0PlxuICAgICAgICA8bGVnZW5kPkVudGVyIGEgY29tbWFuZDo8L2xlZ2VuZD5cbiAgICAgICAgPENvbnRyb2xsZWRJbnB1dFxuICAgICAgICAgIHZhbHVlPXtjb21tYW5kU3RyaW5nfVxuICAgICAgICAgIHNldFZhbHVlPXtzZXRDb21tYW5kU3RyaW5nfVxuICAgICAgICAgIGFyaWFMYWJlbD17XCJDb21tYW5kIElucHV0IEJveCB0byB0eXBlIGluIGNvbW1hbmRzXCJ9XG4gICAgICAgICAgb25LZXlEb3duPXtoYW5kbGVFbnRlclByZXNzfVxuICAgICAgICAvPlxuICAgICAgPC9maWVsZHNldD5cbiAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gaGFuZGxlU3VibWl0KGNvbW1hbmRTdHJpbmcpfT5TdWJtaXQ8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL3pkemlsb3dza2EvRGVza3RvcC91bml2ZXJzaXR5L3llYXIgMi9jczAzMjAvbWFwcy1qemR6aWxvdy1zcHNhbmRvdi9zcmMvZnJvbnRlbmQvY29tcG9uZW50cy9SRVBMSW5wdXQudHN4In0=