import {
  require_react
} from "/node_modules/.vite/deps/chunk-ZVMIEU5R.js?v=b2f08eeb";
import "/node_modules/.vite/deps/chunk-UXIASGQL.js?v=b2f08eeb";
export default require_react();
//# sourceMappingURL=react.js.map
