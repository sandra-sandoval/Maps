import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/components/map/WrappedMap.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b2f08eeb"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/WrappedMap.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import Map, { Layer, Source } from "/node_modules/.vite/deps/react-map-gl.js?v=b2f08eeb";
import "/node_modules/mapbox-gl/dist/mapbox-gl.css";
import { ACCESS_TOKEN } from "/src/frontend/private /api.ts";
import __vite__cjsImport6_react from "/node_modules/.vite/deps/react.js?v=b2f08eeb"; const useEffect = __vite__cjsImport6_react["useEffect"]; const useRef = __vite__cjsImport6_react["useRef"]; const useState = __vite__cjsImport6_react["useState"];
import { fetchFilteredData, fetchMockedData, fetchRedliningData, filteredLayer, geoLayer } from "/src/frontend/components/map/overlays.ts?t=1699747782057";
import { Popup } from "/node_modules/.vite/deps/react-map-gl.js?v=b2f08eeb";
import { MapInput } from "/src/frontend/components/map/MapInput.tsx?t=1699747363238";
const WrappedMap = () => {
  _s();
  const mapRef = useRef(null);
  const [viewState, setViewState] = useState({
    longitude: 19.944544,
    latitude: 50.049683,
    zoom: 1
  });
  const [redliningOverlay, setRedliningOverlay] = useState(void 0);
  const [filteredOverlay, setFilteredOverlay] = useState(void 0);
  const [popupInfo, setPopupInfo] = useState(null);
  useEffect(() => {
    fetchRedliningData().then((redlining) => setRedliningOverlay(redlining));
  }, []);
  const focusMap = (state, county, broadband) => {
    fetch(`https://api.mapbox.com/geocoding/v5/mapbox.places/${county},${state}.json?access_token=${ACCESS_TOKEN}`).then((response) => response.json()).then((data) => {
      const coordinates = data.features[0].geometry.coordinates;
      if (mapRef.current) {
        mapRef.current.flyTo({
          center: coordinates,
          zoom: 10
          // Adjust the zoom level as needed
        });
        const popupContent = /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { children: [
            "State: ",
            state || "N/A"
          ] }, void 0, true, {
            fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/WrappedMap.tsx",
            lineNumber: 36,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: [
            "County: ",
            county || "N/A"
          ] }, void 0, true, {
            fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/WrappedMap.tsx",
            lineNumber: 37,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: [
            "Broadband Access Percent: ",
            broadband || "N/A"
          ] }, void 0, true, {
            fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/WrappedMap.tsx",
            lineNumber: 38,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/WrappedMap.tsx",
          lineNumber: 35,
          columnNumber: 30
        }, this);
        setPopupInfo({
          longitude: coordinates[0],
          latitude: coordinates[1],
          content: popupContent
        });
      }
    }).catch((error) => alert("Error encountered: " + error));
  };
  async function onMapClick(e) {
    if (!redliningOverlay || !mapRef.current) {
      return;
    }
    const bbox = [[e.point.x, e.point.y], [e.point.x, e.point.y]];
    const features = mapRef.current.queryRenderedFeatures(bbox, {
      layers: ["redlining"]
    });
    if (features.length > 0) {
      const feature = features[0];
      if (feature.properties) {
        const state = feature.properties.state;
        const city = feature.properties.city;
        const name = feature.properties.name;
        const lngLat = e.lngLat;
        const lon = lngLat.lng;
        const lat = lngLat.lat;
        const broadband = await fetchBroadband(lat, lon);
        const popupContent = /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { children: [
            "State: ",
            state || "N/A"
          ] }, void 0, true, {
            fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/WrappedMap.tsx",
            lineNumber: 68,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: [
            "City: ",
            city || "N/A"
          ] }, void 0, true, {
            fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/WrappedMap.tsx",
            lineNumber: 69,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: [
            "Broadband Access Percent: ",
            broadband || "N/A"
          ] }, void 0, true, {
            fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/WrappedMap.tsx",
            lineNumber: 70,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: [
            "Name: ",
            name || "N/A"
          ] }, void 0, true, {
            fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/WrappedMap.tsx",
            lineNumber: 71,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/WrappedMap.tsx",
          lineNumber: 67,
          columnNumber: 30
        }, this);
        setPopupInfo({
          longitude: lon,
          latitude: lat,
          content: popupContent
        });
      }
    } else {
      setPopupInfo(null);
    }
  }
  async function fetchBroadband(lat, lon) {
    const countyResponse = await fetch("https://geo.fcc.gov/api/census/area?lat=" + lat + "&lon=" + lon + "&censusYear=2020&format=json");
    if (countyResponse.ok) {
      const data = await countyResponse.json();
      const countyFull = data.results[0].county_name;
      const county = countyFull.replace(" County", "").trim();
      const state = data.results[0].state_name;
      const broadbandResponse = await fetch(`http://localhost:3232/broadband?state=${state}&county=${county}`);
      if (broadbandResponse.ok) {
        const data2 = await broadbandResponse.json();
        const resultMessage = data2.result === "success" ? data2.broadband_access_percent : data2.error_message;
        return resultMessage;
      }
      return void 0;
    }
  }
  const addFilteredLayer = (keyword) => {
    if (keyword == "mock") {
      fetchMockedData().then((filteredData) => {
        setFilteredOverlay(filteredData);
        alert("Mocked data overlayed successfully");
      });
    } else {
      fetchFilteredData(keyword).then((filteredData) => {
        if (filteredData?.features.length === 0) {
          alert("No areas matching sought-after keyword found");
          setFilteredOverlay(void 0);
        } else
          setFilteredOverlay(filteredData);
      });
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "map-container", children: [
    /* @__PURE__ */ jsxDEV(Map, { ref: mapRef, mapboxAccessToken: ACCESS_TOKEN, longitude: viewState.longitude, latitude: viewState.latitude, zoom: viewState.zoom, onMove: (ev) => setViewState(ev.viewState), onClick: (ev) => onMapClick(ev), style: {
      width: window.innerWidth,
      height: window.innerHeight
    }, mapStyle: "mapbox://styles/mapbox/streets-v12", children: [
      /* @__PURE__ */ jsxDEV(Source, { id: "redliningLayer", type: "geojson", data: redliningOverlay, children: /* @__PURE__ */ jsxDEV(Layer, { ...geoLayer }, void 0, false, {
        fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/WrappedMap.tsx",
        lineNumber: 121,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/WrappedMap.tsx",
        lineNumber: 120,
        columnNumber: 9
      }, this),
      filteredOverlay && /* @__PURE__ */ jsxDEV(Source, { id: "filteredLayer", type: "geojson", data: filteredOverlay, children: /* @__PURE__ */ jsxDEV(Layer, { ...filteredLayer }, void 0, false, {
        fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/WrappedMap.tsx",
        lineNumber: 124,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/WrappedMap.tsx",
        lineNumber: 123,
        columnNumber: 29
      }, this),
      popupInfo && /* @__PURE__ */ jsxDEV(Popup, { longitude: popupInfo.longitude, latitude: popupInfo.latitude, closeButton: true, closeOnClick: false, onClose: () => setPopupInfo(null), children: popupInfo.content }, void 0, false, {
        fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/WrappedMap.tsx",
        lineNumber: 126,
        columnNumber: 23
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/WrappedMap.tsx",
      lineNumber: 116,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(MapInput, { ariaLabel: "Command Box for Inputting Map Requests", focusMap, addFilteredLayer }, void 0, false, {
      fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/WrappedMap.tsx",
      lineNumber: 130,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/WrappedMap.tsx",
    lineNumber: 115,
    columnNumber: 10
  }, this);
};
_s(WrappedMap, "vn1SthhItU6YAZDAl8NMZMMoPhI=");
_c = WrappedMap;
export default WrappedMap;
var _c;
$RefreshReg$(_c, "WrappedMap");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/map/WrappedMap.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkRjOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNEZCxPQUFPQSxPQUNMQyxPQU1BQyxjQUVLO0FBQ1AsT0FBTztBQUNQLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFnQkMsV0FBV0MsUUFBUUMsZ0JBQWdCO0FBQ25ELFNBQ0VDLG1CQUNBQyxpQkFDQUMsb0JBQ0FDLGVBQ0FDLGdCQUNLO0FBQ1AsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxnQkFBZ0I7QUFHekIsTUFBTUMsYUFBYUEsTUFBTTtBQUFBQyxLQUFBO0FBQ3ZCLFFBQU1DLFNBQVNYLE9BQWUsSUFBSTtBQUNsQyxRQUFNLENBQUNZLFdBQVdDLFlBQVksSUFBSVosU0FBUztBQUFBLElBQ3pDYSxXQUFXO0FBQUEsSUFDWEMsVUFBVTtBQUFBLElBQ1ZDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFDRCxRQUFNLENBQUNDLGtCQUFrQkMsbUJBQW1CLElBQUlqQixTQUU5Q2tCLE1BQVM7QUFDWCxRQUFNLENBQUNDLGlCQUFpQkMsa0JBQWtCLElBQUlwQixTQUU1Q2tCLE1BQVM7QUFDWCxRQUFNLENBQUNHLFdBQVdDLFlBQVksSUFBSXRCLFNBQTJCLElBQUk7QUFFakVGLFlBQVUsTUFBTTtBQUNkSyx1QkFBbUIsRUFBRW9CLEtBQU1DLGVBQWNQLG9CQUFvQk8sU0FBUyxDQUFDO0FBQUEsRUFDekUsR0FBRyxFQUFFO0FBRUwsUUFBTUMsV0FBV0EsQ0FBQ0MsT0FBZUMsUUFBZ0JDLGNBQXNCO0FBQ3JFQyxVQUNHLHFEQUFvREYsTUFBTyxJQUFHRCxLQUFNLHNCQUFxQjdCLFlBQWEsRUFDekcsRUFDRzBCLEtBQU1PLGNBQWFBLFNBQVNDLEtBQUssQ0FBQyxFQUNsQ1IsS0FBTVMsVUFBUztBQUVkLFlBQU1DLGNBQWNELEtBQUtFLFNBQVMsQ0FBQyxFQUFFQyxTQUFTRjtBQUM5QyxVQUFJdkIsT0FBTzBCLFNBQVM7QUFFbEIxQixlQUFPMEIsUUFBUUMsTUFBTTtBQUFBLFVBQ25CQyxRQUFRTDtBQUFBQSxVQUNSbEIsTUFBTTtBQUFBO0FBQUEsUUFDUixDQUFDO0FBQ0QsY0FBTXdCLGVBQ0osdUJBQUMsU0FDQztBQUFBLGlDQUFDLE9BQUU7QUFBQTtBQUFBLFlBQVFiLFNBQVM7QUFBQSxlQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwQjtBQUFBLFVBQzFCLHVCQUFDLE9BQUU7QUFBQTtBQUFBLFlBQVNDLFVBQVU7QUFBQSxlQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QjtBQUFBLFVBQzVCLHVCQUFDLE9BQUU7QUFBQTtBQUFBLFlBQTJCQyxhQUFhO0FBQUEsZUFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUQ7QUFBQSxhQUhuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFHRk4scUJBQWE7QUFBQSxVQUNYVCxXQUFXb0IsWUFBWSxDQUFDO0FBQUEsVUFDeEJuQixVQUFVbUIsWUFBWSxDQUFDO0FBQUEsVUFDdkJPLFNBQVNEO0FBQUFBLFFBQ1gsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLENBQUMsRUFDQUUsTUFBT0MsV0FBVUMsTUFBTSx3QkFBd0JELEtBQUssQ0FBQztBQUFBLEVBQzFEO0FBRUEsaUJBQWVFLFdBQVdDLEdBQXVCO0FBRS9DLFFBQUksQ0FBQzdCLG9CQUFvQixDQUFDTixPQUFPMEIsU0FBUztBQUN4QztBQUFBLElBQ0Y7QUFDQSxVQUFNVSxPQUErQixDQUNuQyxDQUFDRCxFQUFFRSxNQUFNQyxHQUFHSCxFQUFFRSxNQUFNRSxDQUFDLEdBQ3JCLENBQUNKLEVBQUVFLE1BQU1DLEdBQUdILEVBQUVFLE1BQU1FLENBQUMsQ0FBQztBQUV4QixVQUFNZixXQUFXeEIsT0FBTzBCLFFBQVFjLHNCQUFzQkosTUFBTTtBQUFBLE1BQzFESyxRQUFRLENBQUMsV0FBVztBQUFBLElBQ3RCLENBQUM7QUFDRCxRQUFJakIsU0FBU2tCLFNBQVMsR0FBRztBQUN2QixZQUFNQyxVQUFVbkIsU0FBUyxDQUFDO0FBQzFCLFVBQUltQixRQUFRQyxZQUFZO0FBQ3RCLGNBQU01QixRQUFRMkIsUUFBUUMsV0FBVzVCO0FBQ2pDLGNBQU02QixPQUFPRixRQUFRQyxXQUFXQztBQUNoQyxjQUFNQyxPQUFPSCxRQUFRQyxXQUFXRTtBQUNoQyxjQUFNQyxTQUFTWixFQUFFWTtBQUNqQixjQUFNQyxNQUFNRCxPQUFPRTtBQUNuQixjQUFNQyxNQUFNSCxPQUFPRztBQUVuQixjQUFNaEMsWUFBWSxNQUFNaUMsZUFBZUQsS0FBS0YsR0FBRztBQUMvQyxjQUFNbkIsZUFDSix1QkFBQyxTQUNDO0FBQUEsaUNBQUMsT0FBRTtBQUFBO0FBQUEsWUFBUWIsU0FBUztBQUFBLGVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBCO0FBQUEsVUFDMUIsdUJBQUMsT0FBRTtBQUFBO0FBQUEsWUFBTzZCLFFBQVE7QUFBQSxlQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QjtBQUFBLFVBQ3hCLHVCQUFDLE9BQUU7QUFBQTtBQUFBLFlBQTJCM0IsYUFBYTtBQUFBLGVBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlEO0FBQUEsVUFDakQsdUJBQUMsT0FBRTtBQUFBO0FBQUEsWUFBTzRCLFFBQVE7QUFBQSxlQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QjtBQUFBLGFBSjFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUdGbEMscUJBQWE7QUFBQSxVQUNYVCxXQUFXNkM7QUFBQUEsVUFDWDVDLFVBQVU4QztBQUFBQSxVQUNWcEIsU0FBU0Q7QUFBQUEsUUFDWCxDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsT0FBTztBQUVMakIsbUJBQWEsSUFBSTtBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUVBLGlCQUFldUMsZUFDYkQsS0FDQUYsS0FDNkI7QUFDN0IsVUFBTUksaUJBQWlCLE1BQU1qQyxNQUMzQiw2Q0FDRStCLE1BQ0EsVUFDQUYsTUFDQSw4QkFDSjtBQUNBLFFBQUlJLGVBQWVDLElBQUk7QUFDckIsWUFBTS9CLE9BQU8sTUFBTThCLGVBQWUvQixLQUFLO0FBQ3ZDLFlBQU1pQyxhQUFxQmhDLEtBQUtpQyxRQUFRLENBQUMsRUFBRUM7QUFDM0MsWUFBTXZDLFNBQWlCcUMsV0FBV0csUUFBUSxXQUFXLEVBQUUsRUFBRUMsS0FBSztBQUM5RCxZQUFNMUMsUUFBUU0sS0FBS2lDLFFBQVEsQ0FBQyxFQUFFSTtBQUM5QixZQUFNQyxvQkFBb0IsTUFBTXpDLE1BQzdCLHlDQUF3Q0gsS0FBTSxXQUFVQyxNQUFPLEVBQ2xFO0FBQ0EsVUFBSTJDLGtCQUFrQlAsSUFBSTtBQUN4QixjQUFNUSxRQUFRLE1BQU1ELGtCQUFrQnZDLEtBQUs7QUFDM0MsY0FBTXlDLGdCQUNKRCxNQUFNRSxXQUFXLFlBQ2JGLE1BQU1HLDJCQUNOSCxNQUFNSTtBQUNaLGVBQU9IO0FBQUFBLE1BQ1Q7QUFDQSxhQUFPdEQ7QUFBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFFQSxRQUFNMEQsbUJBQW1CQSxDQUFDQyxZQUFvQjtBQUM1QyxRQUFJQSxXQUFXLFFBQVE7QUFDckIzRSxzQkFBZ0IsRUFBRXFCLEtBQU11RCxrQkFBaUI7QUFDdkMxRCwyQkFBbUIwRCxZQUFZO0FBQy9CbkMsY0FBTSxvQ0FBb0M7QUFBQSxNQUM1QyxDQUFDO0FBQUEsSUFDSCxPQUFPO0FBQ0wxQyx3QkFBa0I0RSxPQUFPLEVBQUV0RCxLQUFNdUQsa0JBQWlCO0FBQ2hELFlBQUlBLGNBQWM1QyxTQUFTa0IsV0FBVyxHQUFHO0FBQ3ZDVCxnQkFBTSw4Q0FBOEM7QUFDcER2Qiw2QkFBbUJGLE1BQVM7QUFBQSxRQUM5QjtBQUFPRSw2QkFBbUIwRCxZQUFZO0FBQUEsTUFDeEMsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSwyQkFBQyxPQUNDLEtBQUtwRSxRQUNMLG1CQUFtQmIsY0FDbkIsV0FBV2MsVUFBVUUsV0FDckIsVUFBVUYsVUFBVUcsVUFDcEIsTUFBTUgsVUFBVUksTUFDaEIsUUFBUSxDQUFDZ0UsT0FBNkJuRSxhQUFhbUUsR0FBR3BFLFNBQVMsR0FDL0QsU0FBUyxDQUFDb0UsT0FBMkJuQyxXQUFXbUMsRUFBRSxHQUNsRCxPQUFPO0FBQUEsTUFBRUMsT0FBT0MsT0FBT0M7QUFBQUEsTUFBWUMsUUFBUUYsT0FBT0c7QUFBQUEsSUFBWSxHQUM5RCxVQUFVLHNDQUVWO0FBQUEsNkJBQUMsVUFBTyxJQUFHLGtCQUFpQixNQUFLLFdBQVUsTUFBTXBFLGtCQUMvQyxpQ0FBQyxTQUFNLEdBQUlYLFlBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQixLQUR0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNDYyxtQkFDQyx1QkFBQyxVQUFPLElBQUcsaUJBQWdCLE1BQUssV0FBVSxNQUFNQSxpQkFDOUMsaUNBQUMsU0FBTSxHQUFJZixpQkFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCLEtBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRURpQixhQUNDLHVCQUFDLFNBQ0MsV0FBV0EsVUFBVVIsV0FDckIsVUFBVVEsVUFBVVAsVUFDcEIsYUFBYSxNQUNiLGNBQWMsT0FDZCxTQUFTLE1BQU1RLGFBQWEsSUFBSSxHQUUvQkQsb0JBQVVtQixXQVBiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLFNBNUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4QkE7QUFBQSxJQUNBLHVCQUFDLFlBQ0MsV0FBVSwwQ0FDVixVQUNBLG9CQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHcUM7QUFBQSxPQW5DdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFDQTtBQUVKO0FBQUUvQixHQXRMSUQsWUFBVTtBQUFBNkUsS0FBVjdFO0FBd0xOLGVBQWVBO0FBQVcsSUFBQTZFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJNYXAiLCJMYXllciIsIlNvdXJjZSIsIkFDQ0VTU19UT0tFTiIsInVzZUVmZmVjdCIsInVzZVJlZiIsInVzZVN0YXRlIiwiZmV0Y2hGaWx0ZXJlZERhdGEiLCJmZXRjaE1vY2tlZERhdGEiLCJmZXRjaFJlZGxpbmluZ0RhdGEiLCJmaWx0ZXJlZExheWVyIiwiZ2VvTGF5ZXIiLCJQb3B1cCIsIk1hcElucHV0IiwiV3JhcHBlZE1hcCIsIl9zIiwibWFwUmVmIiwidmlld1N0YXRlIiwic2V0Vmlld1N0YXRlIiwibG9uZ2l0dWRlIiwibGF0aXR1ZGUiLCJ6b29tIiwicmVkbGluaW5nT3ZlcmxheSIsInNldFJlZGxpbmluZ092ZXJsYXkiLCJ1bmRlZmluZWQiLCJmaWx0ZXJlZE92ZXJsYXkiLCJzZXRGaWx0ZXJlZE92ZXJsYXkiLCJwb3B1cEluZm8iLCJzZXRQb3B1cEluZm8iLCJ0aGVuIiwicmVkbGluaW5nIiwiZm9jdXNNYXAiLCJzdGF0ZSIsImNvdW50eSIsImJyb2FkYmFuZCIsImZldGNoIiwicmVzcG9uc2UiLCJqc29uIiwiZGF0YSIsImNvb3JkaW5hdGVzIiwiZmVhdHVyZXMiLCJnZW9tZXRyeSIsImN1cnJlbnQiLCJmbHlUbyIsImNlbnRlciIsInBvcHVwQ29udGVudCIsImNvbnRlbnQiLCJjYXRjaCIsImVycm9yIiwiYWxlcnQiLCJvbk1hcENsaWNrIiwiZSIsImJib3giLCJwb2ludCIsIngiLCJ5IiwicXVlcnlSZW5kZXJlZEZlYXR1cmVzIiwibGF5ZXJzIiwibGVuZ3RoIiwiZmVhdHVyZSIsInByb3BlcnRpZXMiLCJjaXR5IiwibmFtZSIsImxuZ0xhdCIsImxvbiIsImxuZyIsImxhdCIsImZldGNoQnJvYWRiYW5kIiwiY291bnR5UmVzcG9uc2UiLCJvayIsImNvdW50eUZ1bGwiLCJyZXN1bHRzIiwiY291bnR5X25hbWUiLCJyZXBsYWNlIiwidHJpbSIsInN0YXRlX25hbWUiLCJicm9hZGJhbmRSZXNwb25zZSIsImRhdGEyIiwicmVzdWx0TWVzc2FnZSIsInJlc3VsdCIsImJyb2FkYmFuZF9hY2Nlc3NfcGVyY2VudCIsImVycm9yX21lc3NhZ2UiLCJhZGRGaWx0ZXJlZExheWVyIiwia2V5d29yZCIsImZpbHRlcmVkRGF0YSIsImV2Iiwid2lkdGgiLCJ3aW5kb3ciLCJpbm5lcldpZHRoIiwiaGVpZ2h0IiwiaW5uZXJIZWlnaHQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIldyYXBwZWRNYXAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBNYXAsIHtcbiAgTGF5ZXIsXG4gIExuZ0xhdCxcbiAgTWFwTGF5ZXJNb3VzZUV2ZW50LFxuICBNYXBMYXllclRvdWNoRXZlbnQsXG4gIE1hcFJlZixcbiAgUG9pbnRMaWtlLFxuICBTb3VyY2UsXG4gIFZpZXdTdGF0ZUNoYW5nZUV2ZW50LFxufSBmcm9tIFwicmVhY3QtbWFwLWdsXCI7XG5pbXBvcnQgXCJtYXBib3gtZ2wvZGlzdC9tYXBib3gtZ2wuY3NzXCI7XG5pbXBvcnQgeyBBQ0NFU1NfVE9LRU4gfSBmcm9tIFwiLi4vLi4vcHJpdmF0ZSAvYXBpXCI7XG5pbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQge1xuICBmZXRjaEZpbHRlcmVkRGF0YSxcbiAgZmV0Y2hNb2NrZWREYXRhLFxuICBmZXRjaFJlZGxpbmluZ0RhdGEsXG4gIGZpbHRlcmVkTGF5ZXIsXG4gIGdlb0xheWVyLFxufSBmcm9tIFwiLi9vdmVybGF5c1wiO1xuaW1wb3J0IHsgUG9wdXAgfSBmcm9tIFwicmVhY3QtbWFwLWdsXCI7XG5pbXBvcnQgeyBNYXBJbnB1dCB9IGZyb20gXCIuL01hcElucHV0XCI7XG5pbXBvcnQgeyBQb3B1cEluZm8gfSBmcm9tIFwiLi4vLi4vdHlwZXMvUG9wdXBJbmZvXCI7XG5cbmNvbnN0IFdyYXBwZWRNYXAgPSAoKSA9PiB7XG4gIGNvbnN0IG1hcFJlZiA9IHVzZVJlZjxNYXBSZWY+KG51bGwpO1xuICBjb25zdCBbdmlld1N0YXRlLCBzZXRWaWV3U3RhdGVdID0gdXNlU3RhdGUoe1xuICAgIGxvbmdpdHVkZTogMTkuOTQ0NTQ0LFxuICAgIGxhdGl0dWRlOiA1MC4wNDk2ODMsXG4gICAgem9vbTogMSxcbiAgfSk7XG4gIGNvbnN0IFtyZWRsaW5pbmdPdmVybGF5LCBzZXRSZWRsaW5pbmdPdmVybGF5XSA9IHVzZVN0YXRlPFxuICAgIEdlb0pTT04uRmVhdHVyZUNvbGxlY3Rpb24gfCB1bmRlZmluZWRcbiAgPih1bmRlZmluZWQpO1xuICBjb25zdCBbZmlsdGVyZWRPdmVybGF5LCBzZXRGaWx0ZXJlZE92ZXJsYXldID0gdXNlU3RhdGU8XG4gICAgR2VvSlNPTi5GZWF0dXJlQ29sbGVjdGlvbiB8IHVuZGVmaW5lZFxuICA+KHVuZGVmaW5lZCk7XG4gIGNvbnN0IFtwb3B1cEluZm8sIHNldFBvcHVwSW5mb10gPSB1c2VTdGF0ZTxQb3B1cEluZm8gfCBudWxsPihudWxsKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGZldGNoUmVkbGluaW5nRGF0YSgpLnRoZW4oKHJlZGxpbmluZykgPT4gc2V0UmVkbGluaW5nT3ZlcmxheShyZWRsaW5pbmcpKTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IGZvY3VzTWFwID0gKHN0YXRlOiBzdHJpbmcsIGNvdW50eTogc3RyaW5nLCBicm9hZGJhbmQ6IHN0cmluZykgPT4ge1xuICAgIGZldGNoKFxuICAgICAgYGh0dHBzOi8vYXBpLm1hcGJveC5jb20vZ2VvY29kaW5nL3Y1L21hcGJveC5wbGFjZXMvJHtjb3VudHl9LCR7c3RhdGV9Lmpzb24/YWNjZXNzX3Rva2VuPSR7QUNDRVNTX1RPS0VOfWBcbiAgICApXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHJlc3BvbnNlLmpzb24oKSlcbiAgICAgIC50aGVuKChkYXRhKSA9PiB7XG4gICAgICAgIC8vIEV4dHJhY3QgY29vcmRpbmF0ZXMgZnJvbSB0aGUgcmVzcG9uc2VcbiAgICAgICAgY29uc3QgY29vcmRpbmF0ZXMgPSBkYXRhLmZlYXR1cmVzWzBdLmdlb21ldHJ5LmNvb3JkaW5hdGVzO1xuICAgICAgICBpZiAobWFwUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICAvLyBVc2UgdGhlIG9idGFpbmVkIGNvb3JkaW5hdGVzIHRvIHNldCB0aGUgbWFwIGZvY3VzXG4gICAgICAgICAgbWFwUmVmLmN1cnJlbnQuZmx5VG8oe1xuICAgICAgICAgICAgY2VudGVyOiBjb29yZGluYXRlcyxcbiAgICAgICAgICAgIHpvb206IDEwLCAvLyBBZGp1c3QgdGhlIHpvb20gbGV2ZWwgYXMgbmVlZGVkXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgY29uc3QgcG9wdXBDb250ZW50ID0gKFxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPHA+U3RhdGU6IHtzdGF0ZSB8fCBcIk4vQVwifTwvcD5cbiAgICAgICAgICAgICAgPHA+Q291bnR5OiB7Y291bnR5IHx8IFwiTi9BXCJ9PC9wPlxuICAgICAgICAgICAgICA8cD5Ccm9hZGJhbmQgQWNjZXNzIFBlcmNlbnQ6IHticm9hZGJhbmQgfHwgXCJOL0FcIn08L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApO1xuXG4gICAgICAgICAgc2V0UG9wdXBJbmZvKHtcbiAgICAgICAgICAgIGxvbmdpdHVkZTogY29vcmRpbmF0ZXNbMF0sXG4gICAgICAgICAgICBsYXRpdHVkZTogY29vcmRpbmF0ZXNbMV0sXG4gICAgICAgICAgICBjb250ZW50OiBwb3B1cENvbnRlbnQsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiBhbGVydChcIkVycm9yIGVuY291bnRlcmVkOiBcIiArIGVycm9yKSk7XG4gIH07XG5cbiAgYXN5bmMgZnVuY3Rpb24gb25NYXBDbGljayhlOiBNYXBMYXllck1vdXNlRXZlbnQpIHtcbiAgICAvLyBkb24ndCB3YW50IHRvIGNhbGwgaWYgbm8gb3ZlcmxheVxuICAgIGlmICghcmVkbGluaW5nT3ZlcmxheSB8fCAhbWFwUmVmLmN1cnJlbnQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgYmJveDogW1BvaW50TGlrZSwgUG9pbnRMaWtlXSA9IFtcbiAgICAgIFtlLnBvaW50LngsIGUucG9pbnQueV0sXG4gICAgICBbZS5wb2ludC54LCBlLnBvaW50LnldLFxuICAgIF07XG4gICAgY29uc3QgZmVhdHVyZXMgPSBtYXBSZWYuY3VycmVudC5xdWVyeVJlbmRlcmVkRmVhdHVyZXMoYmJveCwge1xuICAgICAgbGF5ZXJzOiBbXCJyZWRsaW5pbmdcIl0sXG4gICAgfSk7XG4gICAgaWYgKGZlYXR1cmVzLmxlbmd0aCA+IDApIHtcbiAgICAgIGNvbnN0IGZlYXR1cmUgPSBmZWF0dXJlc1swXTtcbiAgICAgIGlmIChmZWF0dXJlLnByb3BlcnRpZXMpIHtcbiAgICAgICAgY29uc3Qgc3RhdGUgPSBmZWF0dXJlLnByb3BlcnRpZXMuc3RhdGU7XG4gICAgICAgIGNvbnN0IGNpdHkgPSBmZWF0dXJlLnByb3BlcnRpZXMuY2l0eTtcbiAgICAgICAgY29uc3QgbmFtZSA9IGZlYXR1cmUucHJvcGVydGllcy5uYW1lO1xuICAgICAgICBjb25zdCBsbmdMYXQgPSBlLmxuZ0xhdDtcbiAgICAgICAgY29uc3QgbG9uID0gbG5nTGF0LmxuZztcbiAgICAgICAgY29uc3QgbGF0ID0gbG5nTGF0LmxhdDtcblxuICAgICAgICBjb25zdCBicm9hZGJhbmQgPSBhd2FpdCBmZXRjaEJyb2FkYmFuZChsYXQsIGxvbik7XG4gICAgICAgIGNvbnN0IHBvcHVwQ29udGVudCA9IChcbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPHA+U3RhdGU6IHtzdGF0ZSB8fCBcIk4vQVwifTwvcD5cbiAgICAgICAgICAgIDxwPkNpdHk6IHtjaXR5IHx8IFwiTi9BXCJ9PC9wPlxuICAgICAgICAgICAgPHA+QnJvYWRiYW5kIEFjY2VzcyBQZXJjZW50OiB7YnJvYWRiYW5kIHx8IFwiTi9BXCJ9PC9wPlxuICAgICAgICAgICAgPHA+TmFtZToge25hbWUgfHwgXCJOL0FcIn08L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICk7XG5cbiAgICAgICAgc2V0UG9wdXBJbmZvKHtcbiAgICAgICAgICBsb25naXR1ZGU6IGxvbixcbiAgICAgICAgICBsYXRpdHVkZTogbGF0LFxuICAgICAgICAgIGNvbnRlbnQ6IHBvcHVwQ29udGVudCxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIE5vIGZlYXR1cmVzIGZvdW5kLCBoaWRlIHRoZSBwb3B1cFxuICAgICAgc2V0UG9wdXBJbmZvKG51bGwpO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIGZldGNoQnJvYWRiYW5kKFxuICAgIGxhdDogbnVtYmVyLFxuICAgIGxvbjogbnVtYmVyXG4gICk6IFByb21pc2U8bnVtYmVyIHwgdW5kZWZpbmVkPiB7XG4gICAgY29uc3QgY291bnR5UmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcbiAgICAgIFwiaHR0cHM6Ly9nZW8uZmNjLmdvdi9hcGkvY2Vuc3VzL2FyZWE/bGF0PVwiICtcbiAgICAgICAgbGF0ICtcbiAgICAgICAgXCImbG9uPVwiICtcbiAgICAgICAgbG9uICtcbiAgICAgICAgXCImY2Vuc3VzWWVhcj0yMDIwJmZvcm1hdD1qc29uXCJcbiAgICApO1xuICAgIGlmIChjb3VudHlSZXNwb25zZS5vaykge1xuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGNvdW50eVJlc3BvbnNlLmpzb24oKTtcbiAgICAgIGNvbnN0IGNvdW50eUZ1bGw6IHN0cmluZyA9IGRhdGEucmVzdWx0c1swXS5jb3VudHlfbmFtZTtcbiAgICAgIGNvbnN0IGNvdW50eTogc3RyaW5nID0gY291bnR5RnVsbC5yZXBsYWNlKFwiIENvdW50eVwiLCBcIlwiKS50cmltKCk7XG4gICAgICBjb25zdCBzdGF0ZSA9IGRhdGEucmVzdWx0c1swXS5zdGF0ZV9uYW1lO1xuICAgICAgY29uc3QgYnJvYWRiYW5kUmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcbiAgICAgICAgYGh0dHA6Ly9sb2NhbGhvc3Q6MzIzMi9icm9hZGJhbmQ/c3RhdGU9JHtzdGF0ZX0mY291bnR5PSR7Y291bnR5fWBcbiAgICAgICk7XG4gICAgICBpZiAoYnJvYWRiYW5kUmVzcG9uc2Uub2spIHtcbiAgICAgICAgY29uc3QgZGF0YTIgPSBhd2FpdCBicm9hZGJhbmRSZXNwb25zZS5qc29uKCk7XG4gICAgICAgIGNvbnN0IHJlc3VsdE1lc3NhZ2UgPVxuICAgICAgICAgIGRhdGEyLnJlc3VsdCA9PT0gXCJzdWNjZXNzXCJcbiAgICAgICAgICAgID8gZGF0YTIuYnJvYWRiYW5kX2FjY2Vzc19wZXJjZW50XG4gICAgICAgICAgICA6IGRhdGEyLmVycm9yX21lc3NhZ2U7XG4gICAgICAgIHJldHVybiByZXN1bHRNZXNzYWdlO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gIH1cblxuICBjb25zdCBhZGRGaWx0ZXJlZExheWVyID0gKGtleXdvcmQ6IHN0cmluZykgPT4ge1xuICAgIGlmIChrZXl3b3JkID09IFwibW9ja1wiKSB7XG4gICAgICBmZXRjaE1vY2tlZERhdGEoKS50aGVuKChmaWx0ZXJlZERhdGEpID0+IHtcbiAgICAgICAgc2V0RmlsdGVyZWRPdmVybGF5KGZpbHRlcmVkRGF0YSk7XG4gICAgICAgIGFsZXJ0KFwiTW9ja2VkIGRhdGEgb3ZlcmxheWVkIHN1Y2Nlc3NmdWxseVwiKTtcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBmZXRjaEZpbHRlcmVkRGF0YShrZXl3b3JkKS50aGVuKChmaWx0ZXJlZERhdGEpID0+IHtcbiAgICAgICAgaWYgKGZpbHRlcmVkRGF0YT8uZmVhdHVyZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgYWxlcnQoXCJObyBhcmVhcyBtYXRjaGluZyBzb3VnaHQtYWZ0ZXIga2V5d29yZCBmb3VuZFwiKTtcbiAgICAgICAgICBzZXRGaWx0ZXJlZE92ZXJsYXkodW5kZWZpbmVkKTtcbiAgICAgICAgfSBlbHNlIHNldEZpbHRlcmVkT3ZlcmxheShmaWx0ZXJlZERhdGEpO1xuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtYXAtY29udGFpbmVyXCI+XG4gICAgICA8TWFwXG4gICAgICAgIHJlZj17bWFwUmVmfVxuICAgICAgICBtYXBib3hBY2Nlc3NUb2tlbj17QUNDRVNTX1RPS0VOfVxuICAgICAgICBsb25naXR1ZGU9e3ZpZXdTdGF0ZS5sb25naXR1ZGV9XG4gICAgICAgIGxhdGl0dWRlPXt2aWV3U3RhdGUubGF0aXR1ZGV9XG4gICAgICAgIHpvb209e3ZpZXdTdGF0ZS56b29tfVxuICAgICAgICBvbk1vdmU9eyhldjogVmlld1N0YXRlQ2hhbmdlRXZlbnQpID0+IHNldFZpZXdTdGF0ZShldi52aWV3U3RhdGUpfVxuICAgICAgICBvbkNsaWNrPXsoZXY6IE1hcExheWVyTW91c2VFdmVudCkgPT4gb25NYXBDbGljayhldil9XG4gICAgICAgIHN0eWxlPXt7IHdpZHRoOiB3aW5kb3cuaW5uZXJXaWR0aCwgaGVpZ2h0OiB3aW5kb3cuaW5uZXJIZWlnaHQgfX1cbiAgICAgICAgbWFwU3R5bGU9e1wibWFwYm94Oi8vc3R5bGVzL21hcGJveC9zdHJlZXRzLXYxMlwifVxuICAgICAgPlxuICAgICAgICA8U291cmNlIGlkPVwicmVkbGluaW5nTGF5ZXJcIiB0eXBlPVwiZ2VvanNvblwiIGRhdGE9e3JlZGxpbmluZ092ZXJsYXl9PlxuICAgICAgICAgIDxMYXllciB7Li4uZ2VvTGF5ZXJ9IC8+XG4gICAgICAgIDwvU291cmNlPlxuICAgICAgICB7ZmlsdGVyZWRPdmVybGF5ICYmIChcbiAgICAgICAgICA8U291cmNlIGlkPVwiZmlsdGVyZWRMYXllclwiIHR5cGU9XCJnZW9qc29uXCIgZGF0YT17ZmlsdGVyZWRPdmVybGF5fT5cbiAgICAgICAgICAgIDxMYXllciB7Li4uZmlsdGVyZWRMYXllcn0gLz5cbiAgICAgICAgICA8L1NvdXJjZT5cbiAgICAgICAgKX1cbiAgICAgICAge3BvcHVwSW5mbyAmJiAoXG4gICAgICAgICAgPFBvcHVwXG4gICAgICAgICAgICBsb25naXR1ZGU9e3BvcHVwSW5mby5sb25naXR1ZGV9XG4gICAgICAgICAgICBsYXRpdHVkZT17cG9wdXBJbmZvLmxhdGl0dWRlfVxuICAgICAgICAgICAgY2xvc2VCdXR0b249e3RydWV9XG4gICAgICAgICAgICBjbG9zZU9uQ2xpY2s9e2ZhbHNlfVxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0UG9wdXBJbmZvKG51bGwpfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtwb3B1cEluZm8uY29udGVudH1cbiAgICAgICAgICA8L1BvcHVwPlxuICAgICAgICApfVxuICAgICAgPC9NYXA+XG4gICAgICA8TWFwSW5wdXRcbiAgICAgICAgYXJpYUxhYmVsPVwiQ29tbWFuZCBCb3ggZm9yIElucHV0dGluZyBNYXAgUmVxdWVzdHNcIlxuICAgICAgICBmb2N1c01hcD17Zm9jdXNNYXB9XG4gICAgICAgIGFkZEZpbHRlcmVkTGF5ZXI9e2FkZEZpbHRlcmVkTGF5ZXJ9XG4gICAgICAvPlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgV3JhcHBlZE1hcDtcbiJdLCJmaWxlIjoiL1VzZXJzL3pkemlsb3dza2EvRGVza3RvcC91bml2ZXJzaXR5L3llYXIgMi9jczAzMjAvbWFwcy1qemR6aWxvdy1zcHNhbmRvdi9zcmMvZnJvbnRlbmQvY29tcG9uZW50cy9tYXAvV3JhcHBlZE1hcC50c3gifQ==