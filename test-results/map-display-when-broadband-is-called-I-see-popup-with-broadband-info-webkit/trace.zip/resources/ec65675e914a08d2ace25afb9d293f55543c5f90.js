import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/components/REPLHistory.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b2f08eeb"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPLHistory.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/frontend/styles/main.css";
export function REPLHistory(props) {
  const {
    commandHistory,
    mode,
    commandResultMap,
    ariaLabel
  } = props;
  const renderData = (data) => {
    if (data.length === 0) {
      return "No data to display";
    }
    if (Array.isArray(data) && Array.isArray(data[0])) {
      return /* @__PURE__ */ jsxDEV("table", { className: "center-table", children: /* @__PURE__ */ jsxDEV("tbody", { children: data.map((row, rowIndex) => /* @__PURE__ */ jsxDEV("tr", { children: row.map((cell, cellIndex) => /* @__PURE__ */ jsxDEV("td", { children: cell }, cellIndex, false, {
        fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPLHistory.tsx",
        lineNumber: 39,
        columnNumber: 63
      }, this)) }, rowIndex, false, {
        fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPLHistory.tsx",
        lineNumber: 38,
        columnNumber: 60
      }, this)) }, void 0, false, {
        fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPLHistory.tsx",
        lineNumber: 37,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPLHistory.tsx",
        lineNumber: 36,
        columnNumber: 14
      }, this);
    } else if (typeof data === "string") {
      return data;
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-history", "aria-live": "polite", "aria-label": ariaLabel, children: [
    /* @__PURE__ */ jsxDEV("h2", { "aria-live": "polite", children: "Command History" }, void 0, false, {
      fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPLHistory.tsx",
      lineNumber: 51,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("ul", { children: commandHistory.map((command, index) => /* @__PURE__ */ jsxDEV("div", { className: "history-element", children: /* @__PURE__ */ jsxDEV("li", { children: mode === "brief" ? /* @__PURE__ */ jsxDEV("div", { className: "text-box", "aria-live": "polite", children: /* @__PURE__ */ jsxDEV("p", { children: [
      "Output:",
      " ",
      renderData(commandResultMap.get(command) ?? "No data")
    ] }, void 0, true, {
      fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPLHistory.tsx",
      lineNumber: 56,
      columnNumber: 19
    }, this) }, void 0, false, {
      fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPLHistory.tsx",
      lineNumber: 55,
      columnNumber: 35
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "text-box", "aria-live": "polite", children: [
      /* @__PURE__ */ jsxDEV("p", { children: [
        "Command: ",
        command.command
      ] }, void 0, true, {
        fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPLHistory.tsx",
        lineNumber: 61,
        columnNumber: 19
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: [
        "Output:",
        " ",
        renderData(commandResultMap.get(command) ?? "No data")
      ] }, void 0, true, {
        fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPLHistory.tsx",
        lineNumber: 62,
        columnNumber: 19
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPLHistory.tsx",
      lineNumber: 60,
      columnNumber: 26
    }, this) }, void 0, false, {
      fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPLHistory.tsx",
      lineNumber: 54,
      columnNumber: 13
    }, this) }, index, false, {
      fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPLHistory.tsx",
      lineNumber: 53,
      columnNumber: 49
    }, this)) }, void 0, false, {
      fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPLHistory.tsx",
      lineNumber: 52,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPLHistory.tsx",
    lineNumber: 50,
    columnNumber: 10
  }, this);
}
_c = REPLHistory;
var _c;
$RefreshReg$(_c, "REPLHistory");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/zdzilowska/Desktop/university/year 2/cs0320/maps-jzdzilow-spsandov/src/frontend/components/REPLHistory.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0NrQjtBQXBDbEIsT0FBTyxvQkFBb0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFpQnBCLGdCQUFTQSxZQUFZQyxPQUF5QjtBQUNuRCxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBZ0JDO0FBQUFBLElBQU1DO0FBQUFBLElBQWtCQztBQUFBQSxFQUFVLElBQUlKO0FBTzlELFFBQU1LLGFBQWFBLENBQUNDLFNBQXdCO0FBQzFDLFFBQUlBLEtBQUtDLFdBQVcsR0FBRztBQUNyQixhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUlDLE1BQU1DLFFBQVFILElBQUksS0FBS0UsTUFBTUMsUUFBUUgsS0FBSyxDQUFDLENBQUMsR0FBRztBQUNqRCxhQUNFLHVCQUFDLFdBQU0sV0FBVSxnQkFDZixpQ0FBQyxXQUNFQSxlQUFLSSxJQUFJLENBQUNDLEtBQWVDLGFBQ3hCLHVCQUFDLFFBQ0VELGNBQUlELElBQUksQ0FBQ0csTUFBY0MsY0FDdEIsdUJBQUMsUUFBb0JELGtCQUFaQyxXQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEIsQ0FDM0IsS0FITUYsVUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUEsQ0FDRCxLQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLElBRUosV0FBVyxPQUFPTixTQUFTLFVBQVU7QUFDbkMsYUFBT0E7QUFBQUEsSUFHVDtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxnQkFBZSxhQUFVLFVBQVMsY0FBWUYsV0FDM0Q7QUFBQSwyQkFBQyxRQUFHLGFBQVUsVUFBUywrQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzQztBQUFBLElBQ3RDLHVCQUFDLFFBQ0VILHlCQUFlUyxJQUFJLENBQUNLLFNBQVNDLFVBQzVCLHVCQUFDLFNBQWdCLFdBQVUsbUJBQ3pCLGlDQUFDLFFBQ0VkLG1CQUFTLFVBQ1IsdUJBQUMsU0FBSSxXQUFVLFlBQVcsYUFBVSxVQUNsQyxpQ0FBQyxPQUFDO0FBQUE7QUFBQSxNQUNRO0FBQUEsTUFDUEcsV0FBV0YsaUJBQWlCYyxJQUFJRixPQUFPLEtBQUssU0FBUztBQUFBLFNBRnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxZQUFXLGFBQVUsVUFDbEM7QUFBQSw2QkFBQyxPQUFFO0FBQUE7QUFBQSxRQUFVQSxRQUFRQTtBQUFBQSxXQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZCO0FBQUEsTUFDN0IsdUJBQUMsT0FBQztBQUFBO0FBQUEsUUFDUTtBQUFBLFFBQ1BWLFdBQVdGLGlCQUFpQmMsSUFBSUYsT0FBTyxLQUFLLFNBQVM7QUFBQSxXQUZ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQSxLQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQkEsS0FsQlFDLE9BQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQSxDQUNELEtBdEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1QkE7QUFBQSxPQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMEJBO0FBRUo7QUFBQ0UsS0E5RGVuQjtBQUFXLElBQUFtQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUkVQTEhpc3RvcnkiLCJwcm9wcyIsImNvbW1hbmRIaXN0b3J5IiwibW9kZSIsImNvbW1hbmRSZXN1bHRNYXAiLCJhcmlhTGFiZWwiLCJyZW5kZXJEYXRhIiwiZGF0YSIsImxlbmd0aCIsIkFycmF5IiwiaXNBcnJheSIsIm1hcCIsInJvdyIsInJvd0luZGV4IiwiY2VsbCIsImNlbGxJbmRleCIsImNvbW1hbmQiLCJpbmRleCIsImdldCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVQTEhpc3RvcnkudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4uL3N0eWxlcy9tYWluLmNzc1wiO1xuaW1wb3J0IHsgSGlzdG9yeUl0ZW0gfSBmcm9tIFwiLi4vdHlwZXMvSGlzdG9yeUl0ZW1cIjtcblxuLyoqXG4gKiBQcm9wcyBmb3IgdGhlIFJFUExIaXN0b3J5IGNvbXBvbmVudC5cbiAqL1xuaW50ZXJmYWNlIFJFUExIaXN0b3J5UHJvcHMge1xuICBjb21tYW5kSGlzdG9yeTogSGlzdG9yeUl0ZW1bXTtcbiAgbW9kZTogc3RyaW5nO1xuICBjb21tYW5kUmVzdWx0TWFwOiBNYXA8SGlzdG9yeUl0ZW0sIFtbXV0gfCBzdHJpbmc+O1xuICBhcmlhTGFiZWw6IHN0cmluZztcbn1cblxuLyoqXG4gKiBDb21wb25lbnQgcmVzcG9uc2libGUgZm9yIGRpc3BsYXlpbmcgdGhlIGNvbW1hbmQgaGlzdG9yeSBhbmQgY29ycmVzcG9uZGluZyByZXN1bHRzLlxuICogQHBhcmFtIHtSRVBMSGlzdG9yeVByb3BzfSBwcm9wcyAtIFRoZSBwcm9wZXJ0aWVzIHJlcXVpcmVkIGZvciByZW5kZXJpbmcgdGhlIGNvbXBvbmVudC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFJFUExIaXN0b3J5KHByb3BzOiBSRVBMSGlzdG9yeVByb3BzKSB7XG4gIGNvbnN0IHsgY29tbWFuZEhpc3RvcnksIG1vZGUsIGNvbW1hbmRSZXN1bHRNYXAsIGFyaWFMYWJlbCB9ID0gcHJvcHM7XG5cbiAgLyoqXG4gICAqIEZ1bmN0aW9uIGZvciByZW5kZXJpbmcgZGlmZmVyZW50IHR5cGVzIG9mIGRhdGEgaW4gdGhlIGNvbW1hbmQgaGlzdG9yeS5cbiAgICogQHBhcmFtIHtbW11dIHwgc3RyaW5nfSBkYXRhIC0gVGhlIGRhdGEgdG8gYmUgcmVuZGVyZWQuXG4gICAqIEByZXR1cm5zIHtKU1guRWxlbWVudH0gLSBUaGUgcmVuZGVyZWQgZGF0YSBhcyBKU1guXG4gICAqL1xuICBjb25zdCByZW5kZXJEYXRhID0gKGRhdGE6IFtbXV0gfCBzdHJpbmcpID0+IHtcbiAgICBpZiAoZGF0YS5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiBcIk5vIGRhdGEgdG8gZGlzcGxheVwiO1xuICAgIH1cbiAgICBpZiAoQXJyYXkuaXNBcnJheShkYXRhKSAmJiBBcnJheS5pc0FycmF5KGRhdGFbMF0pKSB7XG4gICAgICByZXR1cm4gKFxuICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwiY2VudGVyLXRhYmxlXCI+XG4gICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAge2RhdGEubWFwKChyb3c6IHN0cmluZ1tdLCByb3dJbmRleDogbnVtYmVyKSA9PiAoXG4gICAgICAgICAgICAgIDx0ciBrZXk9e3Jvd0luZGV4fT5cbiAgICAgICAgICAgICAgICB7cm93Lm1hcCgoY2VsbDogc3RyaW5nLCBjZWxsSW5kZXg6IG51bWJlcikgPT4gKFxuICAgICAgICAgICAgICAgICAgPHRkIGtleT17Y2VsbEluZGV4fT57Y2VsbH08L3RkPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgPC90YWJsZT5cbiAgICAgICk7XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgZGF0YSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgcmV0dXJuIGRhdGE7XG4gICAgICAvLyB9IGVsc2Uge1xuICAgICAgLy8gICByZXR1cm4gSlNPTi5zdHJpbmdpZnkoZGF0YSk7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsLWhpc3RvcnlcIiBhcmlhLWxpdmU9XCJwb2xpdGVcIiBhcmlhLWxhYmVsPXthcmlhTGFiZWx9PlxuICAgICAgPGgyIGFyaWEtbGl2ZT1cInBvbGl0ZVwiPkNvbW1hbmQgSGlzdG9yeTwvaDI+XG4gICAgICA8dWw+XG4gICAgICAgIHtjb21tYW5kSGlzdG9yeS5tYXAoKGNvbW1hbmQsIGluZGV4KSA9PiAoXG4gICAgICAgICAgPGRpdiBrZXk9e2luZGV4fSBjbGFzc05hbWU9XCJoaXN0b3J5LWVsZW1lbnRcIj5cbiAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAge21vZGUgPT09IFwiYnJpZWZcIiA/IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtYm94XCIgYXJpYS1saXZlPVwicG9saXRlXCI+XG4gICAgICAgICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgICAgICAgT3V0cHV0OntcIiBcIn1cbiAgICAgICAgICAgICAgICAgICAge3JlbmRlckRhdGEoY29tbWFuZFJlc3VsdE1hcC5nZXQoY29tbWFuZCkgPz8gXCJObyBkYXRhXCIpfVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ib3hcIiBhcmlhLWxpdmU9XCJwb2xpdGVcIj5cbiAgICAgICAgICAgICAgICAgIDxwPkNvbW1hbmQ6IHtjb21tYW5kLmNvbW1hbmR9PC9wPlxuICAgICAgICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgICAgICAgIE91dHB1dDp7XCIgXCJ9XG4gICAgICAgICAgICAgICAgICAgIHtyZW5kZXJEYXRhKGNvbW1hbmRSZXN1bHRNYXAuZ2V0KGNvbW1hbmQpID8/IFwiTm8gZGF0YVwiKX1cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICkpfVxuICAgICAgPC91bD5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL3pkemlsb3dza2EvRGVza3RvcC91bml2ZXJzaXR5L3llYXIgMi9jczAzMjAvbWFwcy1qemR6aWxvdy1zcHNhbmRvdi9zcmMvZnJvbnRlbmQvY29tcG9uZW50cy9SRVBMSGlzdG9yeS50c3gifQ==